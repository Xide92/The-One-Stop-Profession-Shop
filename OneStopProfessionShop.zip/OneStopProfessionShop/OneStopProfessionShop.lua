--[[
    The One Stop Profession Shop
    (internally still called KyroProfGuide in a few variable names below -
    renaming those isn't user-visible, so it was left alone to avoid
    needless risk to a working addon)

    In-game leveling guide for a profession with:
      - auto skill-based highlighting
      - clickable checkboxes to mark steps complete (saved between sessions,
        tracked per character - all characters share this account's addon
        data, so you can view any alt's saved progress from any character)
      - collapsible section headers
      - a Shopping List panel: totals remaining materials, checks your bags,
        and shows where to get each one (Data/Materials.lua) - and combines
        totals across paired secondary/primary professions (e.g. First Aid +
        Tailoring, Fishing + Cooking) when your current character actually
        knows both
    Data for each profession lives in Data/<Profession>.lua.
]]

local ADDON_NAME = "OneStopProfessionShop"

KyroProfGuideDB = KyroProfGuideDB or {}

-- ============================================================
-- Per-character data
-- SavedVariables here are account-wide (not per-character), so all your
-- characters' checkbox/collapse/profession state lives in one file under
-- KyroProfGuideDB.characters, keyed by "Realm - Name". This lets any
-- character view (and even edit) any other character's saved checklist.
-- ============================================================
local function GetCharKey()
    return GetRealmName() .. " - " .. UnitName("player")
end

local function NewCharRecord()
    return { completed = {}, collapsed = {}, farmMode = {} }
end

local function InitDB()
    KyroProfGuideDB.characters = KyroProfGuideDB.characters or {}
    local key = GetCharKey()
    if not KyroProfGuideDB.characters[key] then
        KyroProfGuideDB.characters[key] = NewCharRecord()
    end
    -- Always default to viewing yourself when you log in - switching to an
    -- alt's data is a per-session choice made from the Character dropdown.
    KyroProfGuideDB.viewingCharacter = key
end

local function GetCharData(charKey)
    charKey = charKey or KyroProfGuideDB.viewingCharacter
    KyroProfGuideDB.characters = KyroProfGuideDB.characters or {}
    if not KyroProfGuideDB.characters[charKey] then
        KyroProfGuideDB.characters[charKey] = NewCharRecord()
    end
    return KyroProfGuideDB.characters[charKey]
end

local function IsViewingSelf()
    return KyroProfGuideDB.viewingCharacter == GetCharKey()
end

-- Run this immediately rather than waiting for ADDON_LOADED: dropdown setup
-- further down this file can trigger its initialize callback synchronously
-- during load, before ADDON_LOADED ever fires, so viewingCharacter/characters
-- must already exist by then.
InitDB()

-- ============================================================
-- Which profession is currently selected (per viewed character).
-- Each Data/<Profession>.lua file registers its own name into
-- KyroProfGuideData.ProfessionList, so this list grows automatically
-- as more profession data files are added - no code changes needed here.
-- ============================================================
local function GetCurrentProfession()
    local list = KyroProfGuideData.ProfessionList or {}
    local charData = GetCharData()
    if charData.selectedProfession and KyroProfGuideData[charData.selectedProfession] then
        return charData.selectedProfession
    end
    return list[1]
end

-- ============================================================
-- Some professions (gathering ones) offer two routes: buy/smelt the
-- material with concrete quantities, or farm nodes directly with no
-- fixed number (data.sectionsFarm). Professions without a farm route
-- just always use data.sections.
-- ============================================================
local function HasFarmRoute(data)
    return data.sectionsFarm ~= nil
end

local function GetActiveSections(data, prof)
    local charData = GetCharData()
    if HasFarmRoute(data) and charData.farmMode[prof] then
        return data.sectionsFarm
    end
    return data.sections
end

-- ============================================================
-- Read the player's current skill rank for a given skill line name.
-- Only meaningful for the character actually logged in right now - there's
-- no way to read a different (offline) character's live skill.
-- ============================================================
local function GetSkillRank(skillLineName)
    for i = 1, GetNumSkillLines() do
        local name, isHeader, _, rank, _, _, maxRank = GetSkillLineInfo(i)
        if not isHeader and name == skillLineName then
            return rank, maxRank
        end
    end
    return nil, nil
end

-- ============================================================
-- Professions that share raw materials closely enough that, if your
-- current character knows both, it's worth combining their shopping lists
-- into one total (so you don't undershoot buying cloth for one while
-- leveling the other). Only ever applied to the character actually logged
-- in, since it depends on live skill data.
--
-- Note: Fishing itself never has shopping list entries (it's a pure
-- gathering profession - nothing to buy), so pairing it with Cooking only
-- changes anything if you're viewing Fishing's own (always-empty) list -
-- Cooking's list already includes the fish it needs either way, since
-- Materials.lua already sources them as "caught via Fishing".
-- ============================================================
local COMBINABLE_WITH = {
    ["First Aid"] = "Tailoring",
    ["Tailoring"] = "First Aid",
    ["Fishing"] = "Cooking",
    ["Cooking"] = "Fishing",
}

-- ============================================================
-- Bag scanning
-- Blizzard has migrated the container API to a C_Container namespace on
-- some client versions, removing the old global functions. This shim
-- makes bag scanning work either way instead of erroring out silently.
-- ============================================================
local function GetNumBagSlots(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        return C_Container.GetContainerNumSlots(bag)
    end
    return GetContainerNumSlots(bag)
end

local function GetBagSlotLinkAndCount(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if not info then return nil, nil end
        return info.hyperlink, info.stackCount
    else
        local _, itemCount, _, _, _, _, link = GetContainerItemInfo(bag, slot)
        if not link then
            link = GetContainerItemLink(bag, slot)
        end
        return link, itemCount
    end
end

local function CountInBags(itemName)
    local total = 0
    for bag = 0, 4 do
        local slots = GetNumBagSlots(bag)
        for slot = 1, slots do
            local link, itemCount = GetBagSlotLinkAndCount(bag, slot)
            if link then
                local name = GetItemInfo(link)
                if name == itemName then
                    total = total + (itemCount or 0)
                end
            end
        end
    end
    return total
end

-- ============================================================
-- Formatting helpers
-- ============================================================
local function FormatItems(items)
    local parts = {}
    for _, it in ipairs(items) do
        table.insert(parts, string.format("%dx %s", it.qty, it.name))
    end
    return table.concat(parts, " + ")
end

local function SourcingText(matInfo)
    if not matInfo then return "No sourcing info yet." end
    if matInfo.type == "smelt" then
        local t = "Smelt from " .. matInfo.ore .. " - " .. table.concat(matInfo.zones, ", ")
        if matInfo.note then t = t .. " (" .. matInfo.note .. ")" end
        return t
    elseif matInfo.type == "gather" then
        local base = (matInfo.node and (matInfo.node .. ": ") or "") .. table.concat(matInfo.zones or {}, ", ")
        if matInfo.note then base = base .. " (" .. matInfo.note .. ")" end
        return base
    elseif matInfo.type == "vendor" then
        return "Vendor: " .. table.concat(matInfo.vendors, ", ")
    elseif matInfo.type == "byproduct" or matInfo.type == "combine" then
        return matInfo.note
    end
    return "No sourcing info yet."
end

-- ============================================================
-- Colors
-- ============================================================
local COLOR_DONE   = { 0.5, 0.5, 0.5 }
local COLOR_NOW    = { 0.25, 1, 0.25 }
local COLOR_FUTURE = { 1, 1, 1 }
local COLOR_RANKUP = { 1, 0.6, 0.2 }
local COLOR_BUY    = { 0.4, 0.8, 1 }
local COLOR_HEADER = { 1, 0.82, 0 }
local COLOR_HAVE   = { 0.25, 1, 0.25 }
local COLOR_SHORT  = { 1, 0.4, 0.4 }
local COLOR_NOTE   = { 0.7, 0.7, 1 }

-- Step keys are namespaced by profession - two professions can (and do)
-- have identically-numbered brackets (e.g. both Engineering and
-- Blacksmithing have a "1-30" step), so the profession name has to be part
-- of the key or checking one off would silently check off the other too.
local function StepKey(prof, s)
    return "step_" .. prof .. "_" .. s.low .. "_" .. s.high
end

local function SetFontColor(fontString, color)
    fontString:SetTextColor(color[1], color[2], color[3])
end

-- ============================================================
-- Which items are produced internally by the profession itself
-- (these should never show up on the shopping list)
-- ============================================================
local function IsInternallyProduced(sections, name)
    for _, s in ipairs(sections) do
        if s.type == "step" and s.output then
            for _, o in ipairs(s.output) do
                if o.name == name then return true end
            end
        end
    end
    return false
end

local function ComputeShoppingList(prof, sections, charData)
    local totals = {}
    local firstNeededAt = {} -- name -> lowest step.low that still needs it
    for _, s in ipairs(sections) do
        if s.type == "step" and not charData.completed[StepKey(prof, s)] then
            for _, m in ipairs(s.mats) do
                totals[m.name] = (totals[m.name] or 0) + m.qty
                if not firstNeededAt[m.name] or s.low < firstNeededAt[m.name] then
                    firstNeededAt[m.name] = s.low
                end
            end
        end
    end
    for name in pairs(totals) do
        if IsInternallyProduced(sections, name) then
            totals[name] = nil
            firstNeededAt[name] = nil
        end
    end
    return totals, firstNeededAt
end

-- ============================================================
-- Shared visual theme - dark flat panel instead of the heavy parchment
-- dialog look, with a colored accent header bar
-- ============================================================
local THEME_BG = { 0.06, 0.06, 0.09, 0.96 }
local THEME_BORDER = { 0.55, 0.45, 0.15, 1 }
local THEME_HEADER_BAR = { 0.12, 0.11, 0.18, 1 }
local THEME_ACCENT_TEXT = { 1, 0.82, 0.3 }

local function ApplyModernBackdrop(f)
    f:SetBackdrop({
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = false, edgeSize = 14,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    f:SetBackdropColor(unpack(THEME_BG))
    f:SetBackdropBorderColor(unpack(THEME_BORDER))
end

local function AddHeaderBar(f, width, height)
    local bar = f:CreateTexture(nil, "ARTWORK")
    bar:SetColorTexture(unpack(THEME_HEADER_BAR))
    bar:SetPoint("TOPLEFT", 4, -4)
    bar:SetPoint("TOPRIGHT", -4, -4)
    bar:SetHeight(height)
    return bar
end

-- ============================================================
-- Main frame
-- ============================================================
local frame = CreateFrame("Frame", "KyroProfGuideFrame", UIParent, "BackdropTemplate")
frame:SetSize(480, 610)
frame:SetPoint("CENTER")
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
ApplyModernBackdrop(frame)
AddHeaderBar(frame, 480, 36)
frame:Hide()

local titleIcon = frame:CreateTexture(nil, "OVERLAY")
titleIcon:SetSize(20, 20)
titleIcon:SetPoint("TOPLEFT", 12, -10)
titleIcon:SetTexture("Interface\\GossipFrame\\VendorGossipIcon")

local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("LEFT", titleIcon, "RIGHT", 6, 0)
title:SetText("The One Stop Profession Shop")

local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
closeBtn:SetPoint("TOPRIGHT", -4, -4)

local profDropdown = CreateFrame("Frame", "KyroProfGuideProfDropdown", frame, "UIDropDownMenuTemplate")
profDropdown:SetPoint("TOPLEFT", -8, -46)
UIDropDownMenu_SetWidth(profDropdown, 150)

local shopBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
shopBtn:SetSize(110, 22)
shopBtn:SetPoint("LEFT", profDropdown, "RIGHT", 4, 3)
shopBtn:SetText("Shopping List")

local charDropdown = CreateFrame("Frame", "KyroProfGuideCharDropdown", frame, "UIDropDownMenuTemplate")
charDropdown:SetPoint("TOPLEFT", profDropdown, "BOTTOMLEFT", -8, 6)
UIDropDownMenu_SetWidth(charDropdown, 150)

local farmCheck = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
farmCheck:SetSize(20, 20)
farmCheck:SetPoint("LEFT", charDropdown, "RIGHT", 4, 3)

local farmLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
farmLabel:SetPoint("LEFT", farmCheck, "RIGHT", 2, 1)
farmLabel:SetText("Farm nodes instead of buying/smelting")

local skillText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
skillText:SetPoint("TOP", title, "BOTTOM", 0, -114)
skillText:SetWidth(440)

local scrollFrame = CreateFrame("ScrollFrame", "KyroProfGuideScrollFrame", frame, "UIPanelScrollFrameTemplate")
scrollFrame:SetPoint("TOPLEFT", 20, -168)
scrollFrame:SetPoint("BOTTOMRIGHT", -36, 20)

local content = CreateFrame("Frame", nil, scrollFrame)
content:SetSize(410, 1)
scrollFrame:SetScrollChild(content)

-- ============================================================
-- Shopping List frame
-- ============================================================
local shopFrame = CreateFrame("Frame", "KyroProfGuideShopFrame", UIParent, "BackdropTemplate")
shopFrame:SetSize(420, 460)
shopFrame:SetPoint("CENTER", 30, 0)
shopFrame:SetMovable(true)
shopFrame:EnableMouse(true)
shopFrame:RegisterForDrag("LeftButton")
shopFrame:SetScript("OnDragStart", shopFrame.StartMoving)
shopFrame:SetScript("OnDragStop", shopFrame.StopMovingOrSizing)
ApplyModernBackdrop(shopFrame)
AddHeaderBar(shopFrame, 420, 36)
shopFrame:Hide()

local shopTitleIcon = shopFrame:CreateTexture(nil, "OVERLAY")
shopTitleIcon:SetSize(18, 18)
shopTitleIcon:SetPoint("TOPLEFT", 12, -10)
shopTitleIcon:SetTexture("Interface\\Icons\\INV_Misc_Coin_02")

local shopTitle = shopFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
shopTitle:SetPoint("LEFT", shopTitleIcon, "RIGHT", 6, 0)
shopTitle:SetText("Shopping List - remaining materials")

local shopSubtitle = shopFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
shopSubtitle:SetPoint("TOPLEFT", 20, -44)
shopSubtitle:SetText("")

local shopCloseBtn = CreateFrame("Button", nil, shopFrame, "UIPanelCloseButton")
shopCloseBtn:SetPoint("TOPRIGHT", -4, -4)

local shopScroll = CreateFrame("ScrollFrame", "KyroProfGuideShopScroll", shopFrame, "UIPanelScrollFrameTemplate")
shopScroll:SetPoint("TOPLEFT", 20, -60)
shopScroll:SetPoint("BOTTOMRIGHT", -36, 20)

local shopContent = CreateFrame("Frame", nil, shopScroll)
shopContent:SetSize(350, 1)
shopScroll:SetScrollChild(shopContent)

local shopRowPool = {}

local function AcquireShopRow(index)
    local r = shopRowPool[index]
    if not r then
        r = CreateFrame("Frame", nil, shopContent)
        r:SetSize(350, 20)

        r.nameText = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.nameText:SetPoint("TOPLEFT", 0, 0)
        r.nameText:SetJustifyH("LEFT")
        r.nameText:SetWidth(350)

        r.sourceText = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        r.sourceText:SetPoint("TOPLEFT", r.nameText, "BOTTOMLEFT", 0, -2)
        r.sourceText:SetJustifyH("LEFT")
        r.sourceText:SetWidth(350)

        shopRowPool[index] = r
    end
    return r
end

local RefreshShop -- forward declare
RefreshShop = function()
    local currentProf = GetCurrentProfession()
    local data = KyroProfGuideData[currentProf]
    if not data then return end

    local charData = GetCharData()
    local sections = GetActiveSections(data, currentProf)
    local totals, firstNeededAt = ComputeShoppingList(currentProf, sections, charData)

    -- Combine with a paired profession (e.g. First Aid + Tailoring) only
    -- when viewing your own logged-in character, and only when that
    -- character actually knows both professions right now.
    local combinedWith = nil
    if IsViewingSelf() then
        local pairProf = COMBINABLE_WITH[currentProf]
        if pairProf and KyroProfGuideData[pairProf] then
            local skillA = GetSkillRank(currentProf)
            local skillB = GetSkillRank(pairProf)
            if skillA and skillB then
                combinedWith = pairProf
                local otherData = KyroProfGuideData[pairProf]
                local otherSections = GetActiveSections(otherData, pairProf)
                local otherTotals, otherFirstNeededAt = ComputeShoppingList(pairProf, otherSections, charData)
                for name, qty in pairs(otherTotals) do
                    totals[name] = (totals[name] or 0) + qty
                    if not firstNeededAt[name] or otherFirstNeededAt[name] < firstNeededAt[name] then
                        firstNeededAt[name] = otherFirstNeededAt[name]
                    end
                end
            end
        end
    end

    if combinedWith then
        shopSubtitle:SetText(string.format("Combined with %s - you have both, so shared materials are totaled together.", combinedWith))
        shopSubtitle:Show()
    else
        shopSubtitle:SetText("")
    end

    -- Sort by when you'll actually need each material (lowest skill bracket
    -- first), not alphabetically - so a level-1 item never buries a level-70
    -- one at the top of the list before you're anywhere near needing it.
    local names = {}
    for name in pairs(totals) do table.insert(names, name) end
    table.sort(names, function(a, b)
        if firstNeededAt[a] ~= firstNeededAt[b] then
            return firstNeededAt[a] < firstNeededAt[b]
        end
        return a < b -- stable alphabetical tiebreaker within the same bracket
    end)

    local y = 0
    local idx = 0
    for _, name in ipairs(names) do
        idx = idx + 1
        local r = AcquireShopRow(idx)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, y)
        r:Show()

        local need = totals[name]
        local have = CountInBags(name)
        local color = (have >= need) and COLOR_HAVE or COLOR_SHORT
        r.nameText:SetText(string.format("[skill %d] %s - need %d, have %d", firstNeededAt[name], name, need, have))
        SetFontColor(r.nameText, color)

        local matInfo = KyroProfGuideData.Materials and KyroProfGuideData.Materials[name]
        r.sourceText:SetText(SourcingText(matInfo))

        local rowHeight = 8 + r.nameText:GetStringHeight() + r.sourceText:GetStringHeight()
        y = y - rowHeight
    end

    for i = idx + 1, #shopRowPool do
        shopRowPool[i]:Hide()
    end

    if idx == 0 then
        idx = 1
        local r = AcquireShopRow(1)
        r:ClearAllPoints()
        r:SetPoint("TOPLEFT", 0, 0)
        r:Show()
        r.nameText:SetText("Nothing left to buy - every remaining step is covered!")
        SetFontColor(r.nameText, COLOR_HAVE)
        r.sourceText:SetText("")
        y = -20
    end

    shopContent:SetHeight(math.abs(y) + 20)
end

shopFrame:SetScript("OnShow", RefreshShop)
shopBtn:SetScript("OnClick", function()
    if shopFrame:IsShown() then shopFrame:Hide() else shopFrame:Show() end
end)

-- ============================================================
-- Row pool for the main guide list (headers and steps are reused)
-- ============================================================
local headerPool = {}
local rowPool = {}

local function AcquireHeader(index)
    local h = headerPool[index]
    if not h then
        h = CreateFrame("Button", nil, content)
        h:SetSize(410, 20)
        h:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")

        h.arrow = h:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        h.arrow:SetPoint("LEFT", 0, 0)
        h.arrow:SetWidth(16)

        h.text = h:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        h.text:SetPoint("LEFT", h.arrow, "RIGHT", 2, 0)

        h.progress = h:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        h.progress:SetPoint("LEFT", h.text, "RIGHT", 8, 0)

        headerPool[index] = h
    end
    return h
end

local function AcquireRow(index)
    local r = rowPool[index]
    if not r then
        r = CreateFrame("Frame", nil, content)
        r:SetSize(410, 20)

        r.check = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
        r.check:SetSize(20, 20)
        r.check:SetPoint("TOPLEFT", 6, 0)

        r.craftText = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        r.craftText:SetJustifyH("LEFT")
        r.craftText:SetWidth(360)

        r.matsText = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        r.matsText:SetJustifyH("LEFT")
        r.matsText:SetWidth(360)

        r.noteText = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        r.noteText:SetJustifyH("LEFT")
        r.noteText:SetWidth(360)

        rowPool[index] = r
    end
    return r
end

local function HideUnused(pool, fromIndex)
    for i = fromIndex, #pool do
        pool[i]:Hide()
    end
end

local function CountGroupProgress(prof, sections, startIdx, charData)
    local total, done = 0, 0
    for i = startIdx, #sections do
        local s = sections[i]
        if s.type == "header" then break end
        if s.type == "step" then
            total = total + 1
            if charData.completed[StepKey(prof, s)] then done = done + 1 end
        end
    end
    return done, total
end

local function BuildVendorLine(list)
    return table.concat(list, ", ")
end

-- ============================================================
-- Layout / refresh for the main guide window
-- ============================================================
local Refresh
Refresh = function()
    local currentProf = GetCurrentProfession()
    local data = KyroProfGuideData[currentProf]
    if not data then return end

    local charData = GetCharData()
    local viewingSelf = IsViewingSelf()

    title:SetText("The One Stop Profession Shop")
    UIDropDownMenu_SetText(profDropdown, currentProf)
    UIDropDownMenu_SetText(charDropdown, KyroProfGuideDB.viewingCharacter)

    if HasFarmRoute(data) then
        farmCheck:Show()
        farmLabel:Show()
        farmCheck:SetChecked(charData.farmMode[currentProf])
    else
        farmCheck:Hide()
        farmLabel:Hide()
    end
    farmCheck:SetScript("OnClick", function(btn)
        charData.farmMode[currentProf] = btn:GetChecked() and true or nil
        Refresh()
        if shopFrame:IsShown() then RefreshShop() end
    end)

    local sections = GetActiveSections(data, currentProf)

    local skill, maxSkill
    if viewingSelf then
        skill, maxSkill = GetSkillRank(currentProf)
        if skill then
            skillText:SetText(string.format("Skill: %d / %d", skill, maxSkill or 375))
        else
            skillText:SetText("You have not learned " .. currentProf .. " yet.")
        end
    else
        skillText:SetText("Viewing " .. KyroProfGuideDB.viewingCharacter .. "'s saved checklist - skill highlighting only works for your current character, so only checkboxes apply here.")
    end

    local faction = UnitFactionGroup("player")
    local factionKey = (faction == "Horde") and "horde" or "alliance"

    local y = 0
    local headerIdx, rowIdx = 0, 0
    local collapsedGroup = false

    if not content.introText then
        content.introText = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        content.introText:SetPoint("TOPLEFT", 0, 0)
        content.introText:SetJustifyH("LEFT")
        content.introText:SetWidth(410)
    end
    local introLines = { "|cffffd100Required tools:|r" }
    for _, tool in ipairs(data.tools) do table.insert(introLines, "  " .. tool) end
    table.insert(introLines, "|cffffd100Trainers (skill 1-300):|r  " .. BuildVendorLine(data.trainers.classic[factionKey]))
    content.introText:SetText(table.concat(introLines, "\n"))
    y = y - content.introText:GetStringHeight() - 12

    for sectionIdx, s in ipairs(sections) do
        if s.type == "header" then
            headerIdx = headerIdx + 1
            local h = AcquireHeader(headerIdx)
            h:ClearAllPoints()
            h:SetPoint("TOPLEFT", 0, y)
            h:Show()

            local isCollapsed = charData.collapsed[s.label]
            collapsedGroup = isCollapsed

            local done, total = CountGroupProgress(currentProf, sections, sectionIdx + 1, charData)
            h.arrow:SetText(isCollapsed and "+" or "-")
            h.text:SetText(s.label)
            SetFontColor(h.text, COLOR_HEADER)
            h.progress:SetText(string.format("(%d/%d done)", done, total))

            h:SetScript("OnClick", function()
                charData.collapsed[s.label] = not charData.collapsed[s.label]
                Refresh()
            end)

            y = y - 22

        elseif not collapsedGroup then
            rowIdx = rowIdx + 1
            local r = AcquireRow(rowIdx)
            r:ClearAllPoints()
            r:SetPoint("TOPLEFT", 0, y)
            r:Show()

            r.craftText:ClearAllPoints()
            r.matsText:ClearAllPoints()
            r.noteText:ClearAllPoints()

            if s.type == "step" then
                r.check:Show()
                r.craftText:SetPoint("TOPLEFT", r.check, "TOPRIGHT", 4, -3)
                r.matsText:SetPoint("TOPLEFT", r.craftText, "BOTTOMLEFT", 0, -2)
                r.noteText:SetPoint("TOPLEFT", r.matsText, "BOTTOMLEFT", 0, -2)

                local key = StepKey(currentProf, s)
                local isDone = charData.completed[key]
                r.check:SetChecked(isDone)
                r.check:SetScript("OnClick", function(btn)
                    charData.completed[key] = btn:GetChecked() and true or nil
                    Refresh()
                    if shopFrame:IsShown() then RefreshShop() end
                end)

                local color
                if isDone then
                    color = COLOR_DONE
                elseif skill and skill >= s.low and skill < s.high then
                    color = COLOR_NOW
                elseif skill and skill >= s.high then
                    color = COLOR_DONE
                else
                    color = COLOR_FUTURE
                end

                r.craftText:SetText(string.format("[%d-%d] %s", s.low, s.high, s.label or FormatItems(s.output)))
                SetFontColor(r.craftText, color)
                local matsStr = FormatItems(s.mats)
                r.matsText:SetText(matsStr ~= "" and ("Needs: " .. matsStr) or "")
                SetFontColor(r.matsText, color)
                r.noteText:SetText(s.note or "")
                SetFontColor(r.noteText, color)

                local rowHeight = 14 + r.craftText:GetStringHeight() + r.matsText:GetStringHeight()
                    + (s.note and r.noteText:GetStringHeight() or 0) + 4
                y = y - rowHeight

            elseif s.type == "rankup" then
                r.check:Hide()
                r.check:SetScript("OnClick", nil)
                r.craftText:SetPoint("TOPLEFT", r, "TOPLEFT", 6, -3)
                r.matsText:SetPoint("TOPLEFT", r.craftText, "BOTTOMLEFT", 0, -2)
                r.noteText:SetPoint("TOPLEFT", r.matsText, "BOTTOMLEFT", 0, -2)

                r.craftText:SetText(string.format(">> Train %s (requires level %d) <<", s.rank, s.reqLevel))
                SetFontColor(r.craftText, COLOR_RANKUP)

                local extra = {}
                if s.note then table.insert(extra, s.note) end
                if s.atSkill == 300 then
                    table.insert(extra, "Master trainers: " .. BuildVendorLine(data.trainers.master[factionKey]))
                end
                r.matsText:SetText(table.concat(extra, "  "))
                SetFontColor(r.matsText, COLOR_RANKUP)
                r.noteText:SetText("")

                local rowHeight = 14 + r.craftText:GetStringHeight() + r.matsText:GetStringHeight() + 6
                y = y - rowHeight

            elseif s.type == "buy" then
                r.check:Hide()
                r.check:SetScript("OnClick", nil)
                r.craftText:SetPoint("TOPLEFT", r, "TOPLEFT", 6, -3)
                r.matsText:SetPoint("TOPLEFT", r.craftText, "BOTTOMLEFT", 0, -2)
                r.noteText:SetPoint("TOPLEFT", r.matsText, "BOTTOMLEFT", 0, -2)

                r.craftText:SetText("** Buy: " .. s.name .. " **")
                SetFontColor(r.craftText, COLOR_BUY)
                r.matsText:SetText(s.note)
                SetFontColor(r.matsText, COLOR_BUY)
                r.noteText:SetText("Vendors: " .. BuildVendorLine(s.vendors))
                SetFontColor(r.noteText, COLOR_BUY)

                local rowHeight = 14 + r.craftText:GetStringHeight() + r.matsText:GetStringHeight()
                    + r.noteText:GetStringHeight() + 4
                y = y - rowHeight
            end
        end
    end

    HideUnused(headerPool, headerIdx + 1)
    HideUnused(rowPool, rowIdx + 1)
    content:SetHeight(math.abs(y) + 20)
end

frame:SetScript("OnShow", Refresh)

-- ============================================================
-- Profession dropdown menu
-- ============================================================
local function ProfDropdown_OnClick(self)
    local charData = GetCharData()
    charData.selectedProfession = self.value
    UIDropDownMenu_SetText(profDropdown, self.value)
    Refresh()
    if shopFrame:IsShown() then RefreshShop() end
end

local function ProfDropdown_Initialize(self, level)
    local list = KyroProfGuideData.ProfessionList or {}
    for _, profName in ipairs(list) do
        local info = UIDropDownMenu_CreateInfo()
        info.text = profName
        info.value = profName
        info.func = ProfDropdown_OnClick
        info.checked = (profName == GetCurrentProfession())
        UIDropDownMenu_AddButton(info, level)
    end
end

UIDropDownMenu_Initialize(profDropdown, ProfDropdown_Initialize)

-- ============================================================
-- Character dropdown menu
-- ============================================================
local function CharDropdown_OnClick(self)
    KyroProfGuideDB.viewingCharacter = self.value
    UIDropDownMenu_SetText(charDropdown, self.value)
    Refresh()
    if shopFrame:IsShown() then RefreshShop() end
end

local function CharDropdown_Initialize(self, level)
    local keys = {}
    for k in pairs(KyroProfGuideDB.characters or {}) do
        table.insert(keys, k)
    end
    table.sort(keys)
    local myKey = GetCharKey()
    for _, charKey in ipairs(keys) do
        local info = UIDropDownMenu_CreateInfo()
        info.text = charKey .. (charKey == myKey and " (you)" or "")
        info.value = charKey
        info.func = CharDropdown_OnClick
        info.checked = (charKey == KyroProfGuideDB.viewingCharacter)
        UIDropDownMenu_AddButton(info, level)
    end
end

UIDropDownMenu_Initialize(charDropdown, CharDropdown_Initialize)

-- ============================================================
-- Events
-- ============================================================
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("SKILL_LINES_CHANGED")
eventFrame:RegisterEvent("TRADE_SKILL_UPDATE")
eventFrame:RegisterEvent("BAG_UPDATE")
eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        InitDB()
        return
    end
    if event == "BAG_UPDATE" then
        if shopFrame:IsShown() then RefreshShop() end
        return
    end
    if frame:IsShown() then
        Refresh()
    end
end)

-- ============================================================
-- Slash command
-- ============================================================
SLASH_KYROPROFGUIDE1 = "/1stop"
SlashCmdList["KYROPROFGUIDE"] = function(msg)
    msg = msg and msg:lower():trim() or ""
    if msg == "current" then
        -- Always reports on the character actually logged in, regardless of
        -- which character's data the window is currently viewing.
        local currentProf = GetCurrentProfession()
        local skill = GetSkillRank(currentProf)
        if not skill then
            print("|cff66ccffOSPS:|r you haven't learned " .. currentProf .. " yet.")
            return
        end
        local data = KyroProfGuideData[currentProf]
        local sections = GetActiveSections(data, currentProf)
        local charData = GetCharData(GetCharKey())
        for _, s in ipairs(sections) do
            if s.type == "step" and skill >= s.low and skill < s.high
               and not charData.completed[StepKey(currentProf, s)] then
                local craftStr = s.label or FormatItems(s.output)
                local matsStr = FormatItems(s.mats)
                if matsStr ~= "" then
                    print(string.format("|cff66ccffOSPS:|r [%d-%d] %s (Needs: %s)",
                        s.low, s.high, craftStr, matsStr))
                else
                    print(string.format("|cff66ccffOSPS:|r [%d-%d] %s",
                        s.low, s.high, craftStr))
                end
                return
            end
        end
        print("|cff66ccffOSPS:|r no matching uncompleted step found.")
    elseif msg == "list" then
        local list = KyroProfGuideData.ProfessionList or {}
        print("|cff66ccffOSPS:|r available guides: " .. table.concat(list, ", "))
    elseif msg == "shop" then
        if shopFrame:IsShown() then shopFrame:Hide() else shopFrame:Show() end
    elseif msg == "reset" then
        -- Resets whichever character's checklist is currently being viewed.
        local charData = GetCharData()
        charData.completed = {}
        print("|cff66ccffOSPS:|r cleared checkboxes for " .. KyroProfGuideDB.viewingCharacter .. ".")
        if frame:IsShown() then Refresh() end
        if shopFrame:IsShown() then RefreshShop() end
    else
        if frame:IsShown() then
            frame:Hide()
        else
            frame:Show()
        end
    end
end

-- ============================================================
-- Minimap button
-- Position is saved account-wide (not per-character) since it's a UI
-- preference, not profession-tracking data.
-- ============================================================
local minimapButton = CreateFrame("Button", "OneStopProfessionShopMinimapButton", Minimap)
minimapButton:SetSize(31, 31)
minimapButton:SetFrameStrata("MEDIUM")
minimapButton:SetFrameLevel(8)
minimapButton:RegisterForClicks("LeftButtonUp")
minimapButton:RegisterForDrag("LeftButton")

local minimapIcon = minimapButton:CreateTexture(nil, "BACKGROUND")
minimapIcon:SetSize(20, 20)
minimapIcon:SetPoint("TOPLEFT", 7, -6)
minimapIcon:SetTexture("Interface\\GossipFrame\\VendorGossipIcon")
minimapIcon:SetTexCoord(0.07, 0.93, 0.07, 0.93)

local minimapBorder = minimapButton:CreateTexture(nil, "OVERLAY")
minimapBorder:SetSize(53, 53)
minimapBorder:SetPoint("TOPLEFT")
minimapBorder:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")

local function UpdateMinimapButtonPosition()
    local angle = math.rad(KyroProfGuideDB.minimapAngle or 225)
    local radius = 80
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
end
UpdateMinimapButtonPosition()

minimapButton:SetScript("OnDragStart", function(self)
    self.isDragging = true
    self:SetScript("OnUpdate", function(self)
        local mx, my = Minimap:GetCenter()
        local px, py = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        px, py = px / scale, py / scale
        KyroProfGuideDB.minimapAngle = math.deg(math.atan2(py - my, px - mx))
        UpdateMinimapButtonPosition()
    end)
end)

minimapButton:SetScript("OnDragStop", function(self)
    self:SetScript("OnUpdate", nil)
    -- Slight delay before clearing the drag flag so the click that fires on
    -- mouse-up from the drag doesn't also toggle the window open/closed.
    C_Timer.After(0.1, function() self.isDragging = false end)
end)

minimapButton:SetScript("OnClick", function(self)
    if self.isDragging then return end
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
    end
end)

minimapButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:SetText("The One Stop Profession Shop")
    GameTooltip:AddLine("Click to open - drag to move this button", 0.8, 0.8, 0.8)
    GameTooltip:Show()
end)
minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
