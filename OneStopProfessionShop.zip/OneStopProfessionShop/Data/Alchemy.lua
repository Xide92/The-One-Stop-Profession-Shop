--[[
    Alchemy leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Alchemy leveling routes.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck (green/yellow/orange).
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Alchemy = {

    tools = {
        "No permanent tools required - just vials, which are consumed per craft.",
    },

    sections = {
        { type = "header", label = "1 - 60" },

        { type = "step", low = 1, high = 60,
          output = { { name = "Minor Healing Potion", qty = 65 } },
          mats = {
              { name = "Peacebloom", qty = 65 },
              { name = "Silverleaf", qty = 65 },
              { name = "Empty Vial", qty = 65 },
          },
          note = "Keep all of these - they're the base ingredient for Lesser Healing Potion next." },

        { type = "rankup", atSkill = 60, rank = "Journeyman Alchemy", reqLevel = 10 },

        { type = "header", label = "60 - 140" },

        { type = "step", low = 60, high = 110,
          output = { { name = "Lesser Healing Potion", qty = 65 } },
          mats = {
              { name = "Minor Healing Potion", qty = 65 },
              { name = "Briarthorn", qty = 65 },
          } },

        { type = "step", low = 110, high = 140,
          output = { { name = "Healing Potion", qty = 35 } },
          mats = {
              { name = "Bruiseweed", qty = 35 },
              { name = "Briarthorn", qty = 35 },
              { name = "Leaded Vial", qty = 35 },
          } },

        { type = "rankup", atSkill = 140, rank = "Expert Alchemy", reqLevel = 20 },

        { type = "header", label = "140 - 210" },

        { type = "step", low = 140, high = 155,
          output = { { name = "Lesser Mana Potion", qty = 20 } },
          mats = {
              { name = "Mageroyal", qty = 20 },
              { name = "Stranglekelp", qty = 20 },
              { name = "Empty Vial", qty = 20 },
          },
          note = "Goes yellow for the last 10 points - make a few extra if needed." },

        { type = "step", low = 155, high = 185,
          output = { { name = "Greater Healing Potion", qty = 35 } },
          mats = {
              { name = "Liferoot", qty = 35 },
              { name = "Kingsblood", qty = 35 },
              { name = "Leaded Vial", qty = 35 },
          } },

        { type = "step", low = 185, high = 210,
          output = { { name = "Elixir of Agility", qty = 30 } },
          mats = {
              { name = "Stranglekelp", qty = 30 },
              { name = "Goldthorn", qty = 30 },
              { name = "Leaded Vial", qty = 30 },
          },
          note = "If Goldthorn is scarce, Mana Potion or Lesser Invisibility Potion work as substitutes up to ~195." },

        { type = "rankup", atSkill = 210, rank = "Artisan Alchemy", reqLevel = 35 },

        { type = "header", label = "210 - 300" },

        { type = "step", low = 210, high = 215,
          output = { { name = "Elixir of Greater Defense", qty = 5 } },
          mats = {
              { name = "Wild Steelbloom", qty = 5 },
              { name = "Goldthorn", qty = 5 },
              { name = "Leaded Vial", qty = 5 },
          } },

        { type = "step", low = 215, high = 230,
          output = { { name = "Superior Healing Potion", qty = 15 } },
          mats = {
              { name = "Sungrass", qty = 15 },
              { name = "Khadgar's Whisker", qty = 15 },
              { name = "Crystal Vial", qty = 15 },
          } },

        { type = "step", low = 230, high = 265,
          output = { { name = "Elixir of Detect Undead", qty = 45 } },
          mats = {
              { name = "Arthas' Tears", qty = 45 },
              { name = "Crystal Vial", qty = 45 },
          },
          note = "One of the cheapest recipes in the route - good place to stock up if herb prices are high elsewhere." },

        { type = "step", low = 265, high = 285,
          output = { { name = "Superior Mana Potion", qty = 30 } },
          mats = {
              { name = "Sungrass", qty = 60 },
              { name = "Blindweed", qty = 60 },
              { name = "Crystal Vial", qty = 30 },
          } },

        { type = "step", low = 285, high = 300,
          output = { { name = "Major Healing Potion", qty = 20 } },
          mats = {
              { name = "Golden Sansam", qty = 40 },
              { name = "Mountain Silversage", qty = 20 },
              { name = "Crystal Vial", qty = 20 },
          } },

        { type = "rankup", atSkill = 300, rank = "Master Alchemy (Outland)", reqLevel = 50,
          note = "Can be trained as soon as you arrive in Outland, even right at skill 300." },

        { type = "header", label = "300 - 315" },

        { type = "step", low = 300, high = 315,
          output = { { name = "Volatile Healing Potion", qty = 15 } },
          mats = {
              { name = "Golden Sansam", qty = 15 },
              { name = "Felweed", qty = 15 },
          },
          note = "Adept's Elixir (Dreamfoil + Felweed) or Onslaught Elixir (Mountain Silversage + Felweed) work just as well if you have those herbs instead." },

        { type = "header", label = "315 - 330" },

        { type = "step", low = 315, high = 330,
          output = { { name = "Elixir of Healing Power", qty = 25 } },
          mats = {
              { name = "Golden Sansam", qty = 25 },
              { name = "Dreaming Glory", qty = 25 },
          },
          note = "This is a genuinely useful raid consumable, not just a leveling filler - worth the herbs." },

        { type = "header", label = "330 - 335" },

        { type = "step", low = 330, high = 335,
          output = { { name = "Elixir of Draenic Wisdom", qty = 5 } },
          mats = {
              { name = "Terocone", qty = 5 },
              { name = "Felweed", qty = 5 },
          } },

        { type = "header", label = "335 - 340" },

        { type = "step", low = 335, high = 340,
          output = { { name = "Super Healing Potion", qty = 5 } },
          mats = {
              { name = "Netherbloom", qty = 10 },
              { name = "Felweed", qty = 5 },
          },
          note = "If you're short on Netherbloom, a few more Elixir of Healing Power will carry you the same distance." },

        { type = "buy", name = "Recipe: Super Mana Potion",
          note = "Buy before you reach 340.",
          vendors = { "Daga Ramba (Horde)", "Haalrun (Alliance)" } },

        { type = "header", label = "340 - 355" },

        { type = "step", low = 340, high = 355,
          output = { { name = "Super Mana Potion", qty = 15 } },
          mats = {
              { name = "Dreaming Glory", qty = 30 },
              { name = "Felweed", qty = 15 },
          } },

        { type = "buy", name = "Recipe: Major Dreamless Sleep Potion",
          note = "Buy before you reach 355.",
          vendors = { "Daga Ramba (Horde)", "Leeli Longhaggle (Alliance)" } },

        { type = "header", label = "355 - 375" },

        { type = "step", low = 355, high = 375,
          output = { { name = "Major Dreamless Sleep Potion", qty = 40 } },
          mats = {
              { name = "Dreaming Glory", qty = 40 },
              { name = "Nightmare Vine", qty = 40 },
          },
          note = "Goes green for the last few points - a handful extra may be needed. If your guild has Revered with Lower City, Elixir of Major Shadow Power (Ancient Lichen + Nightmare Vine, recipe from Nakodu in Shattrath) sells better on the AH." },
    },

    trainers = {
        classic = {
            horde = {
                "Yelmak - Orgrimmar",
                "Doctor Herbert Halsey - Undercity",
                "Bena Winterhoof - Thunder Bluff",
                "Camberon - Silvermoon City",
            },
            alliance = {
                "Tally Berryfizz - Ironforge",
                "Lilyssia Nightbreeze - Stormwind City",
                "Ainethil - Darnassus",
                "Lucc - The Exodar",
            },
        },
        master = {
            horde = {
                "Apothecary Antonivich - Hellfire Peninsula (Thrallmar)",
                "Lorokeem - Shattrath City (either faction)",
            },
            alliance = {
                "Alchemist Gribble - Hellfire Peninsula (Honor Hold)",
                "Lorokeem - Shattrath City (either faction)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Alchemy")
