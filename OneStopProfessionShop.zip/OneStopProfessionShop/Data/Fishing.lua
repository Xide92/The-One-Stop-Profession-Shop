--[[
    Fishing leveling data for KyroProfGuide.
    Like Herbalism and Skinning, Fishing has no alternative to actually doing
    the activity - no shopping list entries here. What's different is the
    rank-up gates: past Apprentice, you buy a book or complete a quest instead
    of just training normally.
    Skill numbers are approximate breakpoints - actual skill-ups are random.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Fishing = {

    tools = {
        "-- Fishing Pole upgrades (equip in your ranged slot) --",
        "Fishing Pole: your starting pole, no bonus. Strong Fishing Pole is a cheap early vendor upgrade with a small bonus - worth grabbing right away.",
        "Big Iron Fishing Pole (+20 Fishing, usable at level 25): looted from Shellfish Traps off the southwest coast of Desolace, or bought on the Auction House (often pricey). Good bridge pole for the 125-300 stretch.",
        "Seth's Graphite Fishing Pole (+20 Fishing): reward from 'Rather Be Fishin'' - a quick, easy quest from Seth in Shattrath City (Lower City) once you're in Outland, asking for 8 Pristine Shimmerscale Eel (fished from Terokkar Forest). Grab this as soon as you can.",
        "Nat Pagle's Extreme Angler FC-5000 (+25 Fishing, Horde only): reward from 'Snapjaws, Mon!' from Katoom the Angler in The Hinterlands (kill 15 Saltwater Snapjaw). Best pole available to Horde without the Fishing Extravaganza.",
        "Arcanite Fishing Pole (+35 Fishing): the best pole in the game for this expansion, but only obtainable by winning the weekly Stranglethorn Vale Fishing Extravaganza - a nice-to-have, not something to plan your leveling around.",
        "-- Lures --",
        "Shiny Bauble (+25 Fishing, 10 min) and Nightcrawlers (+50 Fishing, 10 min): cheap, sold by most Trade/Fishing Supply vendors - your everyday lures through the Classic zones.",
        "Aquadynamic Fish Attractor: a stronger lure, craftable by Engineers or bought on the Auction House - switch to this once you're fishing in Outland and fish start getting away often.",
        "Bright Baubles: needed in a few specific higher-difficulty spots (Feralas in Classic, the harder Outland zones) where even Aquadynamic Fish Attractor isn't quite enough - noted on the relevant zones below.",
        "Rule of thumb: always have a lure applied before casting. Going without one in Outland especially means losing a large share of your catches.",
        "Secondary profession - doesn't use one of your two profession slots, every character can learn this alongside Cooking and First Aid.",
        "Pairs naturally with Cooking - most of what you catch can be cooked, leveling both at once.",
    },

    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 75,
          label = "Fish in any starting zone water",
          output = {}, mats = {},
          note = "Zones: Durotar, Tirisfal Glades, Mulgore, Elwynn Forest, Dun Morogh, Teldrassil, Azuremyst Isle, Eversong Woods - any pond, lake, or river works. Lure: Shiny Bauble." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Fishing", reqLevel = 10 },

        { type = "header", label = "75 - 125" },

        { type = "step", low = 75, high = 125,
          label = "Fish in secondary zone waters",
          output = {}, mats = {},
          note = "Zones: Loch Modan, The Barrens, Redridge Mountains, The Wetlands - any zone past the starting areas. Lure: Nightcrawlers. Good time to pick up a Big Iron Fishing Pole if you can find one cheap (usable at level 25)." },

        { type = "buy", name = "Expert Fishing - The Bass and You",
          note = "Buy before you reach 125 - this is how you train past 125, there's no trainer for it. Costs 1 gold, or check the Auction House.",
          vendors = { "Old Man Heming - Booty Bay" } },

        { type = "rankup", atSkill = 125, rank = "Expert Fishing", reqLevel = 20 },

        { type = "header", label = "125 - 225" },

        { type = "step", low = 125, high = 225,
          label = "Fish in varied zones with a lure",
          output = {}, mats = {},
          note = "Zones: Alterac Mountains, Arathi Highlands, Desolace, Stranglethorn Vale, Swamp of Sorrows, Thousand Needles. Lure: Nightcrawlers, or switch to an Aquadynamic Fish Attractor if fish keep getting away." },

        { type = "rankup", atSkill = 225, rank = "Artisan Fishing", reqLevel = 35,
          note = "Requires completing 'Nat Pagle, Angler Extreme' from Nat Pagle in Dustwallow Marsh instead of simple training - catch 4 rare quest-only fish from different zones (including a Feralas Ahi from Feralas, where a Bright Baubles lure helps)." },

        { type = "header", label = "225 - 300" },

        { type = "step", low = 225, high = 300,
          label = "Fish in classic zones (post-quest)",
          output = {}, mats = {},
          note = "Zones: Alterac Mountains, Arathi Highlands, Desolace, Scarlet Monastery, Stranglethorn Vale, Swamp of Sorrows, Thousand Needles - same zones as before, now open without restriction. Lure: Aquadynamic Fish Attractor; switch to Bright Baubles specifically if fishing in Feralas." },

        { type = "buy", name = "Master Fishing - The Art of Angling",
          note = "There's no trainer for this - buy it before continuing. Costs 5 gold, or check the Auction House.",
          vendors = { "Juno Dufrain - Zangarmarsh (Cenarion Refuge)" } },

        { type = "rankup", atSkill = 300, rank = "Master Fishing (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 350" },

        { type = "step", low = 300, high = 350,
          label = "Fish in Zangarmarsh",
          output = {}, mats = {},
          note = "Fish the lakes around Cenarion Refuge. Outland zones want roughly 400 effective skill (base + pole + lure) to stop fish getting away, so pair a pole upgrade with a lure here: Aquadynamic Fish Attractor works well with Seth's Graphite Fishing Pole or Big Iron. Do the 'Rather Be Fishin'' quest in Shattrath as soon as you're able for Seth's Graphite Fishing Pole - it's quick and a permanent +20." },

        { type = "header", label = "350 - 375" },

        { type = "step", low = 350, high = 375,
          label = "Fish in Terokkar Forest",
          output = {}, mats = {},
          note = "Stick to the marked non-flying-restricted areas - avoid the lake near Shattrath City until your skill is much higher, it requires more than this. Terokkar and Nagrand-tier water wants closer to 425 effective skill - Bright Baubles instead of Aquadynamic Fish Attractor if you're still losing fish. You can also stay in Zangarmarsh the whole way if you prefer, but Terokkar's fish are more valuable." },
    },

    trainers = {
        classic = {
            horde = {
                "Lumak - Orgrimmar",
                "Armand Cromwell - Undercity",
                "Drathen - Silvermoon City",
                "Uthan Stillwater - Mulgore",
                "Lau'Tiki - Durotar",
            },
            alliance = {
                "Grimnur Stonebrand - Ironforge",
                "Arnold Leland - Stormwind City",
                "Astaia - Darnassus",
                "Warg Deepwater - Ironforge",
            },
        },
        master = {
            horde = { "No trainer - buy the book from Juno Dufrain (Zangarmarsh, Cenarion Refuge)" },
            alliance = { "No trainer - buy the book from Juno Dufrain (Zangarmarsh, Cenarion Refuge)" },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Fishing")
