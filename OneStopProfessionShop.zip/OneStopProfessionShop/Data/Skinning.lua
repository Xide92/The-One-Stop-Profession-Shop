--[[
    Skinning leveling data for KyroProfGuide.
    Skinning has no alternative to actually killing and skinning beasts - there's
    nothing to buy or craft your way around it, so like Herbalism this is a pure
    zone/mob route with no shopping list entries.
    Skill numbers are approximate breakpoints - actual skill-ups from skinning
    corpses are random, same as any other gathering profession.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Skinning = {

    tools = {
        "Skinning Knife - buy from a Leatherworking Supply vendor near your trainer, or any General/Trade Goods vendor. Doesn't need to be equipped, just carried - you literally cannot skin anything without it.",
        "Free skill-ups: in starting zones especially, other players often kill beasts and don't skin them. Skin any fresh corpse you find, even if you didn't get the kill.",
    },

    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 75,
          label = "Skin beasts for Ruined Leather Scraps / Light Leather",
          output = {}, mats = {},
          note = "Zones: Durotar, Tirisfal Glades, Mulgore (Horde) or Dun Morogh, Elwynn Forest (Alliance) - any starting zone works. You must be level 5+ to pick up the profession." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Skinning", reqLevel = 10 },

        { type = "header", label = "75 - 150" },

        { type = "step", low = 75, high = 150,
          label = "Skin beasts for Medium Leather",
          output = {}, mats = {},
          note = "Zones: Loch Modan, The Barrens, Ashenvale, Stonetalon Mountains." },

        { type = "rankup", atSkill = 125, rank = "Expert Skinning", reqLevel = 20 },

        { type = "header", label = "150 - 205" },

        { type = "step", low = 150, high = 205,
          label = "Skin beasts for Heavy Leather / Heavy Hide",
          output = {}, mats = {},
          note = "Zones: The Wetlands, Redridge Mountains, Duskwood." },

        { type = "rankup", atSkill = 205, rank = "Artisan Skinning", reqLevel = 35 },

        { type = "header", label = "205 - 260" },

        { type = "step", low = 205, high = 260,
          label = "Skin beasts for Thick Leather",
          output = {}, mats = {},
          note = "Zones: The Hinterlands, Feralas (Camp Mojache area works well for both factions)." },

        { type = "header", label = "260 - 300" },

        { type = "step", low = 260, high = 300,
          label = "Skin beasts for Rugged Leather",
          output = {}, mats = {},
          note = "Zone: Un'Goro Crater. You won't be able to skin everything right away, but once you hit 275 the whole zone opens up." },

        { type = "rankup", atSkill = 275, rank = "Master Skinning (Outland)", reqLevel = 50,
          note = "Trainable earlier than most Master ranks - 275 skill instead of 300." },

        { type = "header", label = "300 - 330" },

        { type = "step", low = 300, high = 330,
          label = "Skin Hellboars and Ravagers for Knothide Leather",
          output = {}, mats = {},
          note = "Zone: Hellfire Peninsula. Start on Hellboars; move to Ravager camps once you're 310+." },

        { type = "header", label = "330 - 360" },

        { type = "step", low = 330, high = 360,
          label = "Skin Talbuk and Clefthoof for Knothide Leather",
          output = {}, mats = {},
          note = "Zone: Nagrand - talbuk and clefthoof hotspots throughout the zone." },

        { type = "header", label = "360 - 375" },

        { type = "step", low = 360, high = 375,
          label = "Skin Clefthoof (Nagrand) or Dragonkin (Netherstorm/Blade's Edge)",
          output = {}, mats = {},
          note = "At 360 you can skin every non-elite in Outland. Stay in Nagrand for Thick Clefthoof Leather, or head to Netherstorm/Blade's Edge Mountains for Nether Dragonscale (valuable for Dragonscale Leatherworkers) instead." },
    },

    trainers = {
        classic = {
            horde = {
                "Thuwd - Orgrimmar",
                "Doras - Undercity",
                "Wind Rider Ren'dar - Thunder Bluff",
            },
            alliance = {
                "Balthus Stoneflayer - Ironforge",
                "Corina Steele - Stormwind City",
                "Marda Sungrove - Darnassus",
            },
        },
        master = {
            horde = {
                "Sarah Goode - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Ondrik Nightwind - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Skinning")
