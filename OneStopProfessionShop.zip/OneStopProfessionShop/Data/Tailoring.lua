--[[
    Tailoring leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Tailoring leveling routes.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck (green/yellow/orange).
    Where the source guide offers multiple valid recipes for a bracket, the option
    with the fewest outside dependencies was picked as the main route.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Tailoring = {

    tools = {
        "No permanent tools required for most of the route - a Mana Loom is needed for Bolt of Imbued Netherweave at 325 (located next to the vendor who sells the pattern in Shattrath City).",
    },

    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 45,
          output = { { name = "Bolt of Linen Cloth", qty = 102 } },
          mats   = { { name = "Linen Cloth", qty = 204 } },
          note = "Stop making these once you hit 45 - only make more if you run short later." },

        { type = "step", low = 40, high = 67,
          output = { { name = "Linen Belt", qty = 35 } },
          mats = {
              { name = "Bolt of Linen Cloth", qty = 35 },
              { name = "Coarse Thread", qty = 35 },
          } },

        { type = "step", low = 67, high = 75,
          output = { { name = "Reinforced Linen Cape", qty = 8 } },
          mats = {
              { name = "Bolt of Linen Cloth", qty = 16 },
              { name = "Coarse Thread", qty = 24 },
          } },

        { type = "rankup", atSkill = 75, rank = "Journeyman Tailoring", reqLevel = 10 },

        { type = "header", label = "75 - 125" },

        { type = "step", low = 75, high = 100,
          output = { { name = "Bolt of Woolen Cloth", qty = 45 } },
          mats   = { { name = "Wool Cloth", qty = 135 } } },

        { type = "step", low = 100, high = 110,
          output = { { name = "Simple Kilt", qty = 13 } },
          mats = {
              { name = "Bolt of Linen Cloth", qty = 52 },
              { name = "Fine Thread", qty = 13 },
          },
          note = "Might need a few extra if skill-up luck is bad." },

        { type = "step", low = 110, high = 125,
          output = { { name = "Double-stitched Woolen Shoulders", qty = 15 } },
          mats = {
              { name = "Bolt of Woolen Cloth", qty = 45 },
              { name = "Fine Thread", qty = 30 },
          } },

        { type = "rankup", atSkill = 125, rank = "Expert Tailoring", reqLevel = 20 },

        { type = "header", label = "125 - 205" },

        { type = "step", low = 125, high = 145,
          output = { { name = "Bolt of Silk Cloth", qty = 201 } },
          mats   = { { name = "Silk Cloth", qty = 804 } } },

        { type = "step", low = 145, high = 160,
          output = { { name = "Azure Silk Hood", qty = 18 } },
          mats = {
              { name = "Bolt of Silk Cloth", qty = 36 },
              { name = "Blue Dye", qty = 36 },
              { name = "Fine Thread", qty = 18 },
          },
          note = "May need a few extra if you don't quite reach 160." },

        { type = "step", low = 160, high = 170,
          output = { { name = "Silk Headband", qty = 10 } },
          mats = {
              { name = "Bolt of Silk Cloth", qty = 30 },
              { name = "Fine Thread", qty = 20 },
          } },

        { type = "step", low = 170, high = 175,
          output = { { name = "Formal White Shirt", qty = 5 } },
          mats = {
              { name = "Bolt of Silk Cloth", qty = 15 },
              { name = "Bleach", qty = 10 },
              { name = "Fine Thread", qty = 5 },
          } },

        { type = "step", low = 175, high = 185,
          output = { { name = "Bolt of Mageweave", qty = 94 } },
          mats   = { { name = "Mageweave Cloth", qty = 470 } } },

        { type = "step", low = 185, high = 205,
          output = { { name = "Crimson Silk Vest", qty = 20 } },
          mats = {
              { name = "Bolt of Silk Cloth", qty = 80 },
              { name = "Fine Thread", qty = 40 },
              { name = "Red Dye", qty = 40 },
          } },

        { type = "rankup", atSkill = 205, rank = "Artisan Tailoring", reqLevel = 35 },

        { type = "header", label = "205 - 300" },

        { type = "step", low = 205, high = 215,
          output = { { name = "Crimson Silk Pantaloons", qty = 10 } },
          mats = {
              { name = "Bolt of Silk Cloth", qty = 40 },
              { name = "Red Dye", qty = 20 },
              { name = "Silken Thread", qty = 20 },
          } },

        { type = "step", low = 215, high = 220,
          output = { { name = "Orange Mageweave Shirt", qty = 5 } },
          mats = {
              { name = "Bolt of Mageweave", qty = 5 },
              { name = "Orange Dye", qty = 5 },
              { name = "Heavy Silken Thread", qty = 5 },
          } },

        { type = "step", low = 220, high = 230,
          output = { { name = "Black Mageweave Gloves", qty = 10 } },
          mats = {
              { name = "Bolt of Mageweave", qty = 20 },
              { name = "Heavy Silken Thread", qty = 20 },
          } },

        { type = "step", low = 230, high = 250,
          output = { { name = "Black Mageweave Headband", qty = 23 } },
          mats = {
              { name = "Bolt of Mageweave", qty = 69 },
              { name = "Heavy Silken Thread", qty = 46 },
          } },

        { type = "step", low = 250, high = 260,
          output = { { name = "Bolt of Runecloth", qty = 188 } },
          mats   = { { name = "Runecloth", qty = 940 } } },

        { type = "step", low = 260, high = 280,
          output = { { name = "Runecloth Belt", qty = 25 } },
          mats = {
              { name = "Bolt of Runecloth", qty = 75 },
              { name = "Rune Thread", qty = 25 },
          },
          note = "Goes yellow at 270 - may need a few extra." },

        { type = "step", low = 280, high = 300,
          output = { { name = "Runecloth Gloves", qty = 25 } },
          mats = {
              { name = "Bolt of Runecloth", qty = 100 },
              { name = "Rugged Leather", qty = 100 },
              { name = "Rune Thread", qty = 25 },
          },
          note = "Goes yellow at 290. Brightcloth Cloak (Gold Bar) or Wizardweave Leggings (Dream Dust) work just as well if those materials are cheaper for you." },

        { type = "rankup", atSkill = 300, rank = "Master Tailoring (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          output = { { name = "Bolt of Netherweave", qty = 496 } },
          mats   = { { name = "Netherweave Cloth", qty = 2976 } },
          note = "You'll need all of these later, so making them now is free skill points. Can stop at 325 and top up later - only ~450 Netherweave Cloth is actually needed to just reach 325." },

        { type = "buy", name = "Pattern: Bolt of Imbued Netherweave",
          note = "Buy before you reach 325. A Mana Loom stands right next to the vendor - you'll need it to craft this.",
          vendors = { "Eiin - Shattrath City" } },

        { type = "header", label = "325 - 340" },

        { type = "step", low = 325, high = 340,
          output = { { name = "Bolt of Imbued Netherweave", qty = 102 } },
          mats = {
              { name = "Bolt of Netherweave", qty = 306 },
              { name = "Arcane Dust", qty = 204 },
          },
          note = "Worth making all 102 even past 335, since most high-level recipes use this bolt anyway." },

        { type = "header", label = "340 - 345" },

        { type = "step", low = 340, high = 345,
          output = { { name = "Netherweave Boots", qty = 5 } },
          mats = {
              { name = "Bolt of Netherweave", qty = 30 },
              { name = "Knothide Leather", qty = 10 },
              { name = "Rune Thread", qty = 5 },
          },
          note = "This recipe is taught by your Outland trainer - visit them if you haven't already." },

        { type = "header", label = "345 - 360" },

        { type = "step", low = 345, high = 360,
          output = { { name = "Netherweave Tunic", qty = 20 } },
          mats = {
              { name = "Bolt of Netherweave", qty = 160 },
              { name = "Rune Thread", qty = 40 },
          },
          note = "Recipe sold by Eiin in Shattrath City. Yellow for the last 5 points - may need a couple extra." },

        { type = "header", label = "360 - 375" },

        { type = "step", low = 360, high = 375,
          output = { { name = "Imbued Netherweave Tunic", qty = 17 } },
          mats = {
              { name = "Bolt of Imbued Netherweave", qty = 102 },
              { name = "Netherweb Spider Silk", qty = 34 },
              { name = "Rune Thread", qty = 17 },
          },
          note = "Recipe sold by Arrond in Shadowmoon Valley - requires at least Neutral reputation with The Scryers (not Bind on Pickup, so someone can buy it for you if the NPC is hostile). Yellow near the end - may need more than 17. Imbued Netherweave Robe is an identical-cost alternative from the same vendor." },
    },

    trainers = {
        classic = {
            horde = {
                "Magar - Orgrimmar",
                "Josef Gregorian - Undercity",
                "Tepa - Thunder Bluff",
                "Kil'hala - The Barrens",
                "Bowen Brisboise - Tirisfal Glades",
                "Keelen Sheets - Silvermoon City",
            },
            alliance = {
                "Jormund Stonebrow - Ironforge",
                "Grondal Moonbreeze - Darkshore",
                "Georgio Bolero - Stormwind City",
                "Me'lynn - Darnassus",
                "Eldrin - Elwynn Forest",
                "Refik - The Exodar",
            },
        },
        master = {
            horde = {
                "Dalinna - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Hama - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Tailoring")
