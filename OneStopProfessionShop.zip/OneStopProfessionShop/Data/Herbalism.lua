--[[
    Herbalism leveling data for KyroProfGuide.
    Unlike Mining, Herbalism has no smelting-style shortcut - the only way to
    gain skill is picking herbs directly, so there are no craft quantities or
    shopping list entries here, just which herbs to look for and where.
    Skill numbers are approximate breakpoints - actual skill-ups from picking
    are random, same as any other gathering profession.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Herbalism = {

    tools = {
        "No tools required - just the Herbalism skill itself lets you pick nodes.",
        "While gathering, you have a chance to also find Mote of Life, Mote of Mana, Nightmare Seed, and Fel Lotus from Outland nodes - free bonus materials, no extra effort needed.",
        "Black Lotus is real and valuable, but far too rare to plan your leveling around - treat any you find as a bonus, not a target.",
    },

    sections = {
        { type = "header", label = "1 - 50" },

        { type = "step", low = 1, high = 50,
          label = "Pick Peacebloom, Silverleaf, Earthroot",
          output = {}, mats = {},
          note = "Zones: Elwynn Forest, Durotar, Mulgore, Tirisfal Glades - any starting zone works." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Herbalism", reqLevel = 10 },

        { type = "header", label = "50 - 125" },

        { type = "step", low = 50, high = 125,
          label = "Pick Mageroyal, Briarthorn, Bruiseweed, Stranglekelp, Wild Steelbloom",
          output = {}, mats = {},
          note = "Zones: Loch Modan, The Barrens, Ashenvale, Redridge Mountains, Stonetalon Mountains (Stranglekelp needs coastal/shallow water)." },

        { type = "rankup", atSkill = 125, rank = "Expert Herbalism", reqLevel = 20 },

        { type = "header", label = "125 - 160" },

        { type = "step", low = 125, high = 160,
          label = "Pick Kingsblood, Fadeleaf, Goldthorn, Liferoot, Khadgar's Whisker",
          output = {}, mats = {},
          note = "Zones: Duskwood, Hillsbrad Foothills, Thousand Needles, The Wetlands, Feralas, Swamp of Sorrows, Arathi Highlands." },

        { type = "header", label = "160 - 210" },

        { type = "step", low = 160, high = 210,
          label = "Pick Firebloom, Purple Lotus",
          output = {}, mats = {},
          note = "Zones: Badlands, Searing Gorge, Tanaris, Blasted Lands, Silithus, Felwood." },

        { type = "rankup", atSkill = 200, rank = "Artisan Herbalism", reqLevel = 35 },

        { type = "header", label = "210 - 250" },

        { type = "step", low = 210, high = 250,
          label = "Pick Arthas' Tears, Sungrass, Blindweed, Ghost Mushroom",
          output = {}, mats = {},
          note = "Zones: Western/Eastern Plaguelands, Felwood, Arathi Highlands, Feralas, Tanaris, Un'Goro Crater, Swamp of Sorrows. Ghost Mushroom only grows in caves - The Hinterlands, Maraudon, and Dire Maul East." },

        { type = "header", label = "250 - 290" },

        { type = "step", low = 250, high = 290,
          label = "Pick Gromsblood, Golden Sansam, Dreamfoil, Mountain Silversage, Plaguebloom, Icecap",
          output = {}, mats = {},
          note = "Zones: Felwood, Un'Goro Crater, Western/Eastern Plaguelands, Winterspring." },

        { type = "rankup", atSkill = 275, rank = "Master Herbalism (Outland)", reqLevel = 50,
          note = "Trainable earlier than most Master ranks - 275 skill instead of 300." },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          label = "Pick Felweed, Ragveil",
          output = {}, mats = {},
          note = "Zone: Hellfire Peninsula. You can technically stay here all the way to 375 on Felweed alone, but moving zones as new herbs unlock is faster." },

        { type = "header", label = "325 - 350" },

        { type = "step", low = 325, high = 350,
          label = "Pick Terocone, Dreaming Glory",
          output = {}, mats = {},
          note = "Zone: Terokkar Forest. Dreaming Glory unlocks around 315, so it'll already be available when you arrive here." },

        { type = "header", label = "350 - 375" },

        { type = "step", low = 350, high = 375,
          label = "Pick Netherbloom, Nightmare Vine, Mana Thistle, Fel Lotus",
          output = {}, mats = {},
          note = "Zones: Netherstorm, Shadowmoon Valley, Blade's Edge Mountains." },
    },

    trainers = {
        classic = {
            horde = {
                "Kah Mistrunner - Orgrimmar",
                "Poshken Failgrind - Undercity",
                "Hgarth - Thunder Bluff",
                "Zamja - Silvermoon City",
            },
            alliance = {
                "Alarondo Haigher - Ironforge",
                "Elling Trias - Stormwind City",
                "Aendel Windspear - Darnassus",
                "Meliri Longtail - The Exodar",
            },
        },
        master = {
            horde = {
                "Rejold Barleybrew - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Rorelien - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Herbalism")
