--[[
    Herbalism leveling data for KyroProfGuide.
    Unlike Mining, Herbalism has no smelting-style shortcut - the only way to
    gain skill is picking herbs directly, so there are no craft quantities or
    shopping list entries here, just which herbs to look for and where.
    Skill numbers are approximate breakpoints - actual skill-ups from picking
    are random, same as any other gathering profession.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Herbalism = {

    tools = {
        "No tools required - just the Herbalism skill itself lets you pick nodes.",
        "While gathering, you have a chance to also find Mote of Life, Mote of Mana, Nightmare Seed, and Fel Lotus from Outland nodes - free bonus materials, no extra effort needed.",
        "Black Lotus is real and valuable, but far too rare to plan your leveling around - treat any you find as a bonus, not a target.",
    },

    sections = {
        { type = "header", label = "1 - 50" },

        { type = "step", low = 1, high = 50,
          label = "Pick Peacebloom, Silverleaf, Earthroot",
          output = {}, mats = {},
          note = "Zones: Elwynn Forest, Durotar, Mulgore, Tirisfal Glades - any starting zone works." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Herbalism", reqLevel = 10 },

        { type = "header", label = "50 - 100" },

        { type = "step", low = 50, high = 100,
          label = "Pick Mageroyal, Briarthorn",
          output = {}, mats = {},
          note = "Zones: Loch Modan, The Barrens, Ashenvale." },

        { type = "header", label = "100 - 150" },

        { type = "step", low = 100, high = 150,
          label = "Pick Stranglekelp, Bruiseweed, Wild Steelbloom",
          output = {}, mats = {},
          note = "Zones: Redridge Mountains, Stonetalon Mountains, The Wetlands (Stranglekelp needs coastal/shallow water)." },

        { type = "rankup", atSkill = 125, rank = "Expert Herbalism", reqLevel = 20 },

        { type = "header", label = "150 - 175" },

        { type = "step", low = 150, high = 175,
          label = "Pick Kingsblood, Liferoot",
          output = {}, mats = {},
          note = "Zones: Duskwood, The Wetlands, Hillsbrad Foothills, Thousand Needles." },

        { type = "header", label = "175 - 210" },

        { type = "step", low = 175, high = 210,
          label = "Pick Goldthorn, Khadgar's Whisker, Sungrass",
          output = {}, mats = {},
          note = "Zones: Arathi Highlands, Feralas, Tanaris." },

        { type = "rankup", atSkill = 200, rank = "Artisan Herbalism", reqLevel = 35 },

        { type = "header", label = "210 - 230" },

        { type = "step", low = 210, high = 230,
          label = "Pick Blindweed, Purple Lotus",
          output = {}, mats = {},
          note = "Zones: Swamp of Sorrows, Un'Goro Crater, Silithus." },

        { type = "header", label = "230 - 260" },

        { type = "step", low = 230, high = 260,
          label = "Pick Golden Sansam, Gromsblood, Plaguebloom",
          output = {}, mats = {},
          note = "Zones: Un'Goro Crater, Felwood, Western Plaguelands, Eastern Plaguelands, Burning Steppes." },

        { type = "header", label = "260 - 300" },

        { type = "step", low = 260, high = 300,
          label = "Pick Mountain Silversage, Icecap",
          output = {}, mats = {},
          note = "Zones: Felwood, Winterspring." },

        { type = "rankup", atSkill = 275, rank = "Master Herbalism (Outland)", reqLevel = 50,
          note = "Trainable earlier than most Master ranks - 275 skill instead of 300." },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          label = "Pick Felweed, Ragveil",
          output = {}, mats = {},
          note = "Zone: Hellfire Peninsula. You can technically stay here all the way to 375 on Felweed alone, but moving zones as new herbs unlock is faster." },

        { type = "header", label = "325 - 350" },

        { type = "step", low = 325, high = 350,
          label = "Pick Terocone, Dreaming Glory",
          output = {}, mats = {},
          note = "Zone: Terokkar Forest. Dreaming Glory unlocks around 315, so it'll already be available when you arrive here." },

        { type = "header", label = "350 - 375" },

        { type = "step", low = 350, high = 375,
          label = "Pick Netherbloom, Nightmare Vine, Mana Thistle, Fel Lotus",
          output = {}, mats = {},
          note = "Zones: Netherstorm, Shadowmoon Valley, Blade's Edge Mountains." },
    },

    trainers = {
        classic = {
            horde = {
                "Kah Mistrunner - Orgrimmar",
                "Poshken Failgrind - Undercity",
                "Hgarth - Thunder Bluff",
                "Zamja - Silvermoon City",
            },
            alliance = {
                "Alarondo Haigher - Ironforge",
                "Elling Trias - Stormwind City",
                "Aendel Windspear - Darnassus",
                "Meliri Longtail - The Exodar",
            },
        },
        master = {
            horde = {
                "Rejold Barleybrew - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Rorelien - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Herbalism")
