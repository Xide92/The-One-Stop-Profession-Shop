--[[
    Mining leveling data for KyroProfGuide.
    Mining is a gathering profession, so this is a hybrid:
    - 1-290 uses the smelting shortcut (buy or mine the ore, then smelt it -
      smelting itself grants skill, and gives concrete, listable quantities).
    - 290-375 has no reliable smelt-to-skill numbers, so those brackets just
      point you at the right ore and zones to mine directly (no shopping list
      entry - there's nothing to buy, only somewhere to go).
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Mining = {

    tools = {
        "Mining Pick - required to mine any node (buy from a Mining Supply vendor near your trainer). Doesn't need to be equipped, just carried.",
        "Turn on the 'Find Minerals' tracking filter on your minimap - it'll show nearby veins.",
    },

    sections = {
        { type = "header", label = "1 - 65" },

        { type = "step", low = 1, high = 65,
          output = { { name = "Copper Bar", qty = 120 } },
          mats   = { { name = "Copper Ore", qty = 120 } },
          note = "Smelting counts as a skill-up just like mining does. Or skip buying ore entirely and just mine it yourself in any starting zone." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Mining", reqLevel = 10 },

        { type = "header", label = "65 - 125" },

        { type = "step", low = 65, high = 75,
          output = { { name = "Tin Bar", qty = 70 } },
          mats   = { { name = "Tin Ore", qty = 70 } },
          note = "Goes grey after 75, but you'll need these bars for Bronze in the next step - keep them." },

        { type = "step", low = 75, high = 105,
          output = { { name = "Bronze Bar", qty = 70 } },
          mats = {
              { name = "Copper Bar", qty = 70 },
              { name = "Tin Bar", qty = 70 },
          },
          note = "You may not reach 105 exactly - skill will likely land somewhere between 100-110." },

        { type = "step", low = 105, high = 125,
          output = { { name = "Silver Bar", qty = 30 } },
          mats   = { { name = "Silver Ore", qty = 30 } } },

        { type = "rankup", atSkill = 125, rank = "Expert Mining", reqLevel = 20 },

        { type = "header", label = "125 - 200" },

        { type = "step", low = 125, high = 155,
          output = { { name = "Iron Bar", qty = 58 } },
          mats   = { { name = "Iron Ore", qty = 58 } } },

        { type = "step", low = 155, high = 175,
          output = { { name = "Gold Bar", qty = 23 } },
          mats   = { { name = "Gold Ore", qty = 23 } } },

        { type = "step", low = 175, high = 200,
          output = { { name = "Mithril Bar", qty = 40 } },
          mats   = { { name = "Mithril Ore", qty = 40 } } },

        { type = "rankup", atSkill = 200, rank = "Artisan Mining", reqLevel = 35,
          note = "Trainable as soon as you hit 200, but you don't strictly need it until you'd go past 225." },

        { type = "header", label = "200 - 300" },

        { type = "step", low = 200, high = 230,
          output = { { name = "Mithril Bar", qty = 245 } },
          mats   = { { name = "Mithril Ore", qty = 245 } },
          note = "225-230 has a very low skill-up chance - you may need more than this." },

        { type = "step", low = 230, high = 250,
          output = { { name = "Truesilver Bar", qty = 50 } },
          mats   = { { name = "Truesilver Ore", qty = 50 } } },

        { type = "step", low = 250, high = 290,
          output = { { name = "Thorium Bar", qty = 165 } },
          mats   = { { name = "Thorium Ore", qty = 165 } },
          note = "Smelting stops giving skill-ups after this - the last 10 points have to come from actually mining." },

        { type = "step", low = 290, high = 300,
          label = "Mine Thorium Ore / Rich Thorium Veins",
          output = {}, mats = {},
          note = "Zones: Un'Goro Crater, Eastern Plaguelands, Winterspring, Burning Steppes. No shortcut for this last stretch - has to be mined in person." },

        { type = "rankup", atSkill = 300, rank = "Master Mining (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          label = "Mine Fel Iron Ore",
          output = {}, mats = {},
          note = "Zone: Hellfire Peninsula. Veins are dense along the ridges and Path of Glory - loop the zone edges." },

        { type = "header", label = "325 - 350" },

        { type = "step", low = 325, high = 350,
          label = "Mine Fel Iron Ore / Adamantite Ore",
          output = {}, mats = {},
          note = "Zones: Zangarmarsh, Terokkar Forest. A flying mount helps a lot here - some Rich Adamantite spots are only reachable that way." },

        { type = "header", label = "350 - 375" },

        { type = "step", low = 350, high = 375,
          label = "Mine Adamantite Ore (chance at Khorium Ore)",
          output = {}, mats = {},
          note = "Zones: Nagrand, Netherstorm, Shadowmoon Valley. Khorium has a low spawn rate - don't count on it alone to finish the last few points." },
    },

    -- Alternative route for players who'd rather mine nodes directly than
    -- buy ore and smelt it. There's no fixed "mine X to hit Y skill" number
    -- (skill-ups from mining a vein are random), so these are zone pointers
    -- with a checkbox, not craft steps with a shopping list.
    sectionsFarm = {
        { type = "header", label = "1 - 65" },
        { type = "step", low = 1, high = 65,
          label = "Mine Copper Ore",
          output = {}, mats = {},
          note = "Zones: Durotar, Mulgore, Tirisfal Glades, Elwynn Forest, Darkshore, Dun Morogh. Any starting zone works - Night Elves should head to Darkshore." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Mining", reqLevel = 10 },

        { type = "header", label = "65 - 125" },
        { type = "step", low = 65, high = 125,
          label = "Mine Tin Ore, Copper Ore, Silver Ore",
          output = {}, mats = {},
          note = "Zones: Hillsbrad Foothills, Redridge Mountains, Ashenvale, The Barrens." },

        { type = "rankup", atSkill = 125, rank = "Expert Mining", reqLevel = 20 },

        { type = "header", label = "125 - 175" },
        { type = "step", low = 125, high = 175,
          label = "Mine Iron Ore, Tin Ore, Gold Ore",
          output = {}, mats = {},
          note = "Zones: Arathi Highlands, Desolace, Thousand Needles." },

        { type = "header", label = "175 - 245" },
        { type = "step", low = 175, high = 245,
          label = "Mine Mithril Ore, Truesilver Ore",
          output = {}, mats = {},
          note = "Zones: The Hinterlands, Tanaris." },

        { type = "rankup", atSkill = 200, rank = "Artisan Mining", reqLevel = 35,
          note = "Trainable as soon as you hit 200, but you don't strictly need it until you'd go past 225." },

        { type = "header", label = "245 - 275" },
        { type = "step", low = 245, high = 275,
          label = "Mine Mithril Ore, Truesilver Ore, Thorium Ore",
          output = {}, mats = {},
          note = "Zones: Un'Goro Crater, Blasted Lands, Felwood." },

        { type = "header", label = "275 - 300" },
        { type = "step", low = 275, high = 300,
          label = "Mine Thorium Ore / Rich Thorium Veins",
          output = {}, mats = {},
          note = "Zones: Un'Goro Crater (now with Rich Thorium Veins too), Eastern Plaguelands, Winterspring, Burning Steppes." },

        { type = "rankup", atSkill = 300, rank = "Master Mining (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 325" },
        { type = "step", low = 300, high = 325,
          label = "Mine Fel Iron Ore",
          output = {}, mats = {},
          note = "Zone: Hellfire Peninsula. Veins are dense along the ridges and Path of Glory - loop the zone edges." },

        { type = "header", label = "325 - 350" },
        { type = "step", low = 325, high = 350,
          label = "Mine Fel Iron Ore / Adamantite Ore",
          output = {}, mats = {},
          note = "Zones: Zangarmarsh, Terokkar Forest. A flying mount helps a lot here - some Rich Adamantite spots are only reachable that way." },

        { type = "header", label = "350 - 375" },
        { type = "step", low = 350, high = 375,
          label = "Mine Adamantite Ore (chance at Khorium Ore)",
          output = {}, mats = {},
          note = "Zones: Nagrand, Netherstorm, Shadowmoon Valley. Khorium has a low spawn rate - don't count on it alone to finish the last few points." },
    },

    trainers = {
        classic = {
            horde = {
                "Makaru - Orgrimmar",
                "Brom Killian - Undercity",
                "Brek Stonehoof - Thunder Bluff",
                "Krunn - Durotar",
            },
            alliance = {
                "Geofram Bouldertoe - Ironforge",
                "Gelman Stonehand - Stormwind City",
                "Kurdram Stonehammer - Darkshore",
                "Yarr Hammerstone - Dun Morogh",
            },
        },
        master = {
            horde = {
                "Krugosh - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Hurnak Grimmord - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Mining")
