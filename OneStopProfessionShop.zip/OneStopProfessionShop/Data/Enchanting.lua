--[[
    Enchanting leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Enchanting leveling routes.
    Enchanting doesn't produce a physical item most of the time - the "output"
    listed for most steps is the enchant/rod being cast, and "mats" are what
    it consumes. Rod crafts are mandatory checkpoints (you can't apply enchants
    of that tier without the matching rod), so they're kept as their own steps.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Enchanting = {

    tools = {
        "No permanent tools beyond the rods themselves - each rod tier below is a mandatory checkpoint, not optional gear.",
        "Blood Elf characters get +10 Enchanting from their Arcane Affinity racial - recipes stay orange 10 points longer.",
        "Disenchanting green/blue items you loot or buy cheaply is often more cost-effective than buying dust outright - keep this in mind throughout.",
    },

    sections = {
        { type = "header", label = "1 - 50" },

        { type = "step", low = 1, high = 2,
          output = { { name = "Runed Copper Rod", qty = 1 } },
          mats = {
              { name = "Copper Rod", qty = 1 },
              { name = "Strange Dust", qty = 1 },
              { name = "Lesser Magic Essence", qty = 1 },
          },
          note = "Buy the Copper Rod from a vendor, never the Auction House - it's a trivial cost from a vendor." },

        { type = "step", low = 2, high = 50,
          output = { { name = "Enchant Bracer: Minor Health", qty = 48 } },
          mats   = { { name = "Strange Dust", qty = 48 } } },

        { type = "rankup", atSkill = 50, rank = "Journeyman Enchanting", reqLevel = 10 },

        { type = "header", label = "50 - 135" },

        { type = "step", low = 50, high = 90,
          output = { { name = "Enchant Bracer: Minor Health", qty = 40 } },
          mats   = { { name = "Strange Dust", qty = 40 } },
          note = "If Strange Dust is cheap and Greater Magic Essence is pricey, you can keep making this up to 120 instead of switching." },

        { type = "step", low = 90, high = 100,
          output = { { name = "Enchant Bracer: Minor Stamina", qty = 10 } },
          mats   = { { name = "Strange Dust", qty = 30 } } },

        { type = "step", low = 100, high = 101,
          output = { { name = "Runed Silver Rod", qty = 1 } },
          mats = {
              { name = "Silver Rod", qty = 1 },
              { name = "Strange Dust", qty = 6 },
              { name = "Greater Magic Essence", qty = 3 },
          } },

        { type = "step", low = 101, high = 110,
          output = { { name = "Greater Magic Wand", qty = 9 } },
          mats = {
              { name = "Simple Wood", qty = 9 },
              { name = "Greater Magic Essence", qty = 9 },
          } },

        { type = "buy", name = "Formula: Enchant Bracer - Lesser Strength / Formula: Enchant Cloak - Minor Agility",
          note = "Buy both before you reach 110. Limited supply, 30-50 min respawn - or just buy off the Auction House.",
          vendors = { "Kulwia - Stonetalon Mountains (Horde)", "Dalria - Ashenvale (Alliance)" } },

        { type = "step", low = 110, high = 135,
          output = { { name = "Enchant Cloak: Minor Agility", qty = 25 } },
          mats   = { { name = "Lesser Astral Essence", qty = 25 } } },

        { type = "rankup", atSkill = 135, rank = "Expert Enchanting", reqLevel = 20 },

        { type = "header", label = "135 - 225" },

        { type = "step", low = 135, high = 155,
          output = { { name = "Enchant Bracer - Lesser Stamina", qty = 20 } },
          mats   = { { name = "Soul Dust", qty = 40 } } },

        { type = "step", low = 155, high = 156,
          output = { { name = "Runed Golden Rod", qty = 1 } },
          mats = {
              { name = "Golden Rod", qty = 1 },
              { name = "Iridescent Pearl", qty = 1 },
              { name = "Greater Astral Essence", qty = 2 },
              { name = "Soul Dust", qty = 2 },
          } },

        { type = "step", low = 156, high = 185,
          output = { { name = "Enchant Bracer - Lesser Strength", qty = 40 } },
          mats   = { { name = "Soul Dust", qty = 80 } },
          note = "Turns yellow at 165 - if 2 Soul Dust is cheaper than 1 Lesser Mystic Essence, keep going anyway. Otherwise switch to Enchant Bracer: Spirit (20 Lesser Mystic Essence) for 165-185." },

        { type = "step", low = 185, high = 200,
          output = { { name = "Enchant Bracer: Strength", qty = 15 } },
          mats   = { { name = "Vision Dust", qty = 15 } } },

        { type = "step", low = 200, high = 201,
          output = { { name = "Runed Truesilver Rod", qty = 1 } },
          mats = {
              { name = "Truesilver Rod", qty = 1 },
              { name = "Black Pearl", qty = 1 },
              { name = "Greater Mystic Essence", qty = 2 },
              { name = "Vision Dust", qty = 2 },
          } },

        { type = "step", low = 201, high = 220,
          output = { { name = "Enchant Bracer: Strength", qty = 25 } },
          mats   = { { name = "Vision Dust", qty = 25 } },
          note = "Yellow through this bracket - budget for a few extra casts." },

        { type = "step", low = 220, high = 225,
          output = { { name = "Enchant Cloak: Greater Defense", qty = 5 } },
          mats   = { { name = "Vision Dust", qty = 15 } } },

        { type = "rankup", atSkill = 225, rank = "Artisan Enchanting", reqLevel = 35 },

        { type = "header", label = "225 - 300" },

        { type = "step", low = 225, high = 230,
          output = { { name = "Enchant Gloves: Agility", qty = 5 } },
          mats = {
              { name = "Lesser Nether Essence", qty = 5 },
              { name = "Vision Dust", qty = 5 },
          },
          note = "No Lesser Nether Essence? Enchant Cloak: Greater Defense (Vision Dust only) covers the same range." },

        { type = "step", low = 230, high = 235,
          output = { { name = "Enchant Boots - Stamina", qty = 5 } },
          mats   = { { name = "Vision Dust", qty = 25 } } },

        { type = "step", low = 235, high = 250,
          output = { { name = "Enchant Chest: Superior Health", qty = 25 } },
          mats   = { { name = "Vision Dust", qty = 150 } },
          note = "Keep an eye out for Formula: Enchant Bracer - Greater Stamina on the Auction House (random world drop) - it's the best recipe to carry you from 245 all the way to 265-285 if you find it." },

        { type = "buy", name = "Formula: Lesser Mana Oil",
          note = "Buy before you reach 250.",
          vendors = { "Kania - Silithus (upstairs in the inn)" } },

        { type = "step", low = 250, high = 265,
          output = { { name = "Lesser Mana Oil", qty = 20 } },
          mats = {
              { name = "Dream Dust", qty = 60 },
              { name = "Purple Lotus", qty = 40 },
              { name = "Crystal Vial", qty = 20 },
          },
          note = "Can push to 270 if Purple Lotus is cheap on your server." },

        { type = "buy", name = "Formula: Enchant Shield - Greater Stamina",
          note = "Buy before you reach 265. Binds on pickup and limited supply - don't buy with an alt to mail over, you have to get it on this character.",
          vendors = { "Daniel Bartlett - Undercity", "Mythrin'dir - Darnassus" } },

        { type = "step", low = 265, high = 290,
          output = { { name = "Enchant Shield: Greater Stamina", qty = 27 } },
          mats   = { { name = "Dream Dust", qty = 270 } } },

        { type = "buy", name = "Formula: Enchant Cloak - Superior Defense / Formula: Runed Arcanite Rod",
          note = "Buy both before you reach 290 - same vendor, don't leave without both. Limited supply, 15-20 min respawn.",
          vendors = { "Lorelae Wintersong - Moonglade (Nighthaven)" } },

        { type = "step", low = 290, high = 299,
          output = { { name = "Enchant Cloak: Superior Defense", qty = 9 } },
          mats   = { { name = "Illusion Dust", qty = 72 } },
          note = "If you still have plenty of Dream Dust, or Illusion Dust is expensive, just keep making Enchant Shield: Greater Stamina instead." },

        { type = "step", low = 299, high = 300,
          output = { { name = "Runed Arcanite Rod", qty = 1 } },
          mats = {
              { name = "Arcanite Rod", qty = 1 },
              { name = "Golden Pearl", qty = 1 },
              { name = "Illusion Dust", qty = 10 },
              { name = "Greater Eternal Essence", qty = 4 },
              { name = "Large Brilliant Shard", qty = 2 },
          } },

        { type = "rankup", atSkill = 300, rank = "Master Enchanting (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 310" },

        { type = "step", low = 300, high = 310,
          output = {
              { name = "Runed Fel Iron Rod", qty = 1 },
              { name = "Bracer - Assault", qty = 9 },
          },
          mats = {
              { name = "Fel Iron Rod", qty = 1 },
              { name = "Greater Eternal Essence", qty = 4 },
              { name = "Large Brilliant Shard", qty = 6 },
              { name = "Arcane Dust", qty = 54 },
          },
          note = "Enchant Cloak: Superior Defense (96 Illusion Dust) is a fine substitute for the Bracer - Assault part if Illusion Dust is cheap - you still need to craft the rod either way." },

        { type = "header", label = "310 - 316" },

        { type = "step", low = 310, high = 316,
          output = { { name = "Bracer - Brawn", qty = 6 } },
          mats   = { { name = "Arcane Dust", qty = 36 } } },

        { type = "header", label = "316 - 330" },

        { type = "step", low = 316, high = 330,
          output = { { name = "Gloves - Assault", qty = 16 } },
          mats   = { { name = "Arcane Dust", qty = 128 } },
          note = "Yellow through most of this - budget a few extra. Chest - Major Spirit (20 Greater Planar Essence for 10 casts) is a fine swap if Arcane Dust costs more than Planar Essence on your server." },

        { type = "buy", name = "Recipe: Shield - Major Stamina / Formula: Superior Wizard Oil",
          note = "Buy both before you reach 330 - same vendor, grab both while you're there. Limited supply, 5-10 min respawn.",
          vendors = { "Madame Ruby - Shattrath City" } },

        { type = "header", label = "330 - 335" },

        { type = "step", low = 330, high = 335,
          output = { { name = "Shield - Major Stamina", qty = 5 } },
          mats   = { { name = "Arcane Dust", qty = 75 } },
          note = "Chest - Major Spirit (12 Greater Planar Essence) works as an alternative if you'd rather spend Essence than Dust here." },

        { type = "header", label = "335 - 340" },

        { type = "step", low = 335, high = 340,
          output = { { name = "Shield - Resilience", qty = 5 } },
          mats = {
              { name = "Large Prismatic Shard", qty = 5 },
              { name = "Lesser Planar Essence", qty = 20 },
          },
          note = "Blood Elves only: converting a Large Prismatic Shard to 3 Small Prismatic Shards and back can grant 10 free skill points here through a lucky RNG loop - slow and only worth it if you already have spare shards, not a reliable primary route." },

        { type = "header", label = "340 - 350" },

        { type = "step", low = 340, high = 350,
          output = { { name = "Superior Wizard Oil", qty = 15 } },
          mats = {
              { name = "Arcane Dust", qty = 45 },
              { name = "Nightmare Vine", qty = 15 },
              { name = "Imbued Vial", qty = 15 },
          },
          note = "Already yellow when you learn it - expect to need a few extra. No Nightmare Vine? Just make more Shield - Resilience instead." },

        { type = "header", label = "350 - 360" },

        { type = "step", low = 350, high = 360,
          output = { { name = "Enchant Gloves - Major Strength", qty = 15 } },
          mats = {
              { name = "Arcane Dust", qty = 180 },
              { name = "Greater Planar Essence", qty = 15 },
          } },

        { type = "buy", name = "Formula: Runed Adamantite Rod",
          note = "Buy before you reach 360.",
          vendors = { "Rungor - Terokkar Forest (Stonebreaker Hold, Horde)", "Vodesiin - Hellfire Peninsula (Temple of Telhamat, Alliance)" } },

        { type = "header", label = "360 - 361" },

        { type = "step", low = 360, high = 361,
          output = { { name = "Runed Adamantite Rod", qty = 1 } },
          mats = {
              { name = "Adamantite Rod", qty = 1 },
              { name = "Primal Might", qty = 1 },
              { name = "Greater Planar Essence", qty = 8 },
              { name = "Large Prismatic Shard", qty = 8 },
          },
          note = "Can be made as early as 350, but waiting until 360 means it's still a guaranteed skill point rather than a fading one." },

        { type = "header", label = "361 - 365" },

        { type = "step", low = 361, high = 365,
          output = { { name = "Enchant Gloves - Major Strength", qty = 10 } },
          mats = {
              { name = "Arcane Dust", qty = 120 },
              { name = "Greater Planar Essence", qty = 10 },
          },
          note = "May need more than 10 to close the gap." },

        { type = "buy", name = "Formula: Enchant Ring - Spellpower",
          note = "Requires Honored reputation with the Keepers of Time.",
          vendors = { "Alurmi - Tanaris" } },

        { type = "header", label = "365 - 375" },

        { type = "step", low = 365, high = 375,
          output = { { name = "Enchant Ring: Spellpower", qty = 12 } },
          mats = {
              { name = "Large Prismatic Shard", qty = 24 },
              { name = "Greater Planar Essence", qty = 24 },
          },
          note = "Enchant Ring: Striking is an alternative if you're Revered with The Consortium instead (sold inside Karazhan by Ythyar). If neither reputation is built up, Void Sphere (Void Crystal only) works with no reputation at all, but has a 2-day cooldown per cast - expect 25-40 days to finish this way." },
    },

    trainers = {
        classic = {
            horde = {
                "Godan - Orgrimmar",
                "Lavinia Crowe - Undercity",
                "Teg Dawnstrider - Thunder Bluff",
                "Vance Undergloom - Tirisfal Glades (Brill)",
                "Sedana - Silvermoon City",
            },
            alliance = {
                "Lucan Cordell - Stormwind City",
                "Gimble Thistlefuzz - Ironforge",
                "Taladan - Darnassus",
                "Alanna Raveneye - Teldrassil",
                "Nahogg - The Exodar",
            },
        },
        master = {
            horde = {
                "Felannia - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Johan Barnes - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Enchanting")
