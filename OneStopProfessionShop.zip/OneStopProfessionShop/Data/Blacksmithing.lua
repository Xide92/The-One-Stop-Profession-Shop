--[[
    Blacksmithing leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Blacksmithing leveling routes.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck (green/yellow/orange).
    Several brackets in the source guide offer multiple valid paths (reputation-gated,
    quest-gated, or drop-gated); where that happens, the least prerequisite-heavy
    option was picked as the main route, with alternatives noted.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Blacksmithing = {

    tools = {
        "Blacksmith Hammer - buy from the Blacksmithing Supply vendor near your trainer (a few copper, don't buy off the AH).",
    },

    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 30,
          output = { { name = "Rough Sharpening Stone", qty = 40 } },
          mats   = { { name = "Rough Stone", qty = 40 } } },

        { type = "step", low = 30, high = 65,
          output = { { name = "Rough Grinding Stone", qty = 55 } },
          mats   = { { name = "Rough Stone", qty = 110 } },
          note = "Save 10 of these for later." },

        { type = "step", low = 65, high = 75,
          output = { { name = "Coarse Sharpening Stone", qty = 25 } },
          mats   = { { name = "Coarse Stone", qty = 25 } } },

        { type = "rankup", atSkill = 75, rank = "Journeyman Blacksmithing", reqLevel = 10 },

        { type = "header", label = "75 - 125" },

        { type = "step", low = 75, high = 90,
          output = { { name = "Coarse Grinding Stone", qty = 35 } },
          mats   = { { name = "Coarse Stone", qty = 70 } },
          note = "Save these. If you're short of 90, a few extra Copper Bars into more of these will close the gap." },

        { type = "step", low = 90, high = 100,
          output = { { name = "Runed Copper Belt", qty = 10 } },
          mats   = { { name = "Copper Bar", qty = 100 } } },

        { type = "step", low = 100, high = 105,
          output = { { name = "Silver Rod", qty = 5 } },
          mats = {
              { name = "Silver Bar", qty = 5 },
              { name = "Rough Grinding Stone", qty = 10 },
          },
          note = "Skip this and just keep making Runed Copper Belt if you have no Silver Bar." },

        { type = "step", low = 105, high = 110,
          output = { { name = "Runed Copper Belt", qty = 5 } },
          mats   = { { name = "Copper Bar", qty = 50 } } },

        { type = "step", low = 110, high = 125,
          output = { { name = "Rough Bronze Leggings", qty = 15 } },
          mats   = { { name = "Bronze Bar", qty = 90 } } },

        { type = "rankup", atSkill = 125, rank = "Expert Blacksmithing", reqLevel = 20 },

        { type = "header", label = "125 - 225" },

        { type = "step", low = 125, high = 140,
          output = { { name = "Heavy Grinding Stone", qty = 35 } },
          mats   = { { name = "Heavy Stone", qty = 105 } },
          note = "Keep these. Worth continuing to 150 if Heavy Stone is cheap." },

        { type = "step", low = 140, high = 150,
          output = { { name = "Patterned Bronze Bracers", qty = 10 } },
          mats = {
              { name = "Bronze Bar", qty = 50 },
              { name = "Coarse Grinding Stone", qty = 20 },
          } },

        { type = "step", low = 150, high = 155,
          output = { { name = "Golden Rod", qty = 5 } },
          mats = {
              { name = "Gold Bar", qty = 5 },
              { name = "Coarse Grinding Stone", qty = 10 },
          } },

        { type = "step", low = 155, high = 165,
          output = { { name = "Green Iron Leggings", qty = 10 } },
          mats = {
              { name = "Iron Bar", qty = 80 },
              { name = "Heavy Grinding Stone", qty = 10 },
              { name = "Green Dye", qty = 10 },
          } },

        { type = "step", low = 165, high = 190,
          output = { { name = "Green Iron Bracers", qty = 25 } },
          mats = {
              { name = "Iron Bar", qty = 150 },
              { name = "Green Dye", qty = 25 },
          } },

        { type = "step", low = 190, high = 200,
          output = { { name = "Golden Scale Bracers", qty = 10 } },
          mats = {
              { name = "Steel Bar", qty = 50 },
              { name = "Heavy Grinding Stone", qty = 20 },
          },
          note = "Alliance players should keep 6 of these in case you pick Armorsmithing." },

        { type = "step", low = 200, high = 210,
          output = { { name = "Solid Grinding Stone", qty = 30 } },
          mats   = { { name = "Solid Stone", qty = 120 } },
          note = "Keep at least 10 for the 225-235 step." },

        { type = "step", low = 210, high = 225,
          output = { { name = "Heavy Mithril Gauntlet", qty = 15 } },
          mats = {
              { name = "Mithril Bar", qty = 90 },
              { name = "Mageweave Cloth", qty = 60 },
          } },

        { type = "rankup", atSkill = 225, rank = "Artisan Blacksmithing", reqLevel = 35,
          note = "At skill 200 + character level 40 you can also specialize into Armorsmithing or Weaponsmithing - optional, doesn't affect leveling." },

        { type = "header", label = "225 - 300" },

        { type = "step", low = 225, high = 235,
          output = { { name = "Steel Plate Helm", qty = 10 } },
          mats = {
              { name = "Steel Bar", qty = 140 },
              { name = "Solid Grinding Stone", qty = 10 },
          },
          note = "Horde players should keep 4 in case you pick Armorsmithing." },

        { type = "step", low = 235, high = 270,
          output = { { name = "Mithril Spurs", qty = 35 } },
          mats = {
              { name = "Mithril Bar", qty = 140 },
              { name = "Solid Grinding Stone", qty = 105 },
          },
          note = "Requires buying Plans: Mithril Spurs from the Auction House first. Goes green near 270, so treat the count as approximate." },

        { type = "step", low = 270, high = 295,
          output = { { name = "Imperial Plate Bracers", qty = 28 } },
          mats   = { { name = "Thorium Bar", qty = 336 } },
          note = "Recipe requires completing the Imperial Plate Bracer quest for Derotain Mudsipper in Tanaris (bring 10 Thorium Bar for the quest itself)." },

        { type = "step", low = 295, high = 300,
          output = { { name = "Imperial Plate Boots", qty = 5 } },
          mats   = { { name = "Thorium Bar", qty = 90 } },
          note = "Same Tanaris questline as the previous step - this one needs 20 Thorium Bar to unlock." },

        { type = "rankup", atSkill = 300, rank = "Master Blacksmithing (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 305" },

        { type = "step", low = 300, high = 305,
          output = { { name = "Fel Weightstone", qty = 7 } },
          mats = {
              { name = "Fel Iron Bar", qty = 7 },
              { name = "Netherweave Cloth", qty = 7 },
          },
          note = "Won't skill up on every craft - you may need a few extra." },

        { type = "header", label = "305 - 316" },

        { type = "step", low = 305, high = 316,
          output = { { name = "Fel Iron Plate Belt", qty = 11 } },
          mats   = { { name = "Fel Iron Bar", qty = 44 } } },

        { type = "header", label = "316 - 321" },

        { type = "step", low = 316, high = 321,
          output = { { name = "Fel Iron Chain Gloves", qty = 5 } },
          mats   = { { name = "Fel Iron Bar", qty = 25 } } },

        { type = "header", label = "321 - 325" },

        { type = "step", low = 321, high = 325,
          output = { { name = "Fel Iron Plate Boots", qty = 4 } },
          mats   = { { name = "Fel Iron Bar", qty = 24 } } },

        { type = "header", label = "325 - 335" },

        { type = "step", low = 325, high = 335,
          output = { { name = "Lesser Rune of Warding", qty = 45 } },
          mats   = { { name = "Adamantite Bar", qty = 45 } },
          note = "Green for the last 5 points - 45 is approximate." },

        { type = "header", label = "335 - 340" },

        { type = "step", low = 335, high = 340,
          output = { { name = "Fel Iron Chain Tunic", qty = 7 } },
          mats   = { { name = "Fel Iron Bar", qty = 63 } },
          note = "Yellow for most of this range - may need a couple extra." },

        { type = "buy", name = "Recipe: Lesser Ward of Shielding",
          note = "Buy before you reach 340. Limited supply (15-60 min respawn).",
          vendors = { "Rohok - Hellfire Peninsula (Horde)", "Mari Stonehand - Shadowmoon Valley (Alliance)" } },

        { type = "header", label = "340 - 350" },

        { type = "step", low = 340, high = 350,
          output = { { name = "Lesser Ward of Shielding", qty = 45 } },
          mats   = { { name = "Adamantite Bar", qty = 45 } },
          note = "Green for the last 5 points - approximate." },

        { type = "buy", name = "Recipe: Adamantite Weightstone",
          note = "Buy before you reach 350. Requires Honored reputation with the Cenarion Expedition (earned in Steamvault, Underbog, Slave Pens).",
          vendors = { "Fedryen Swiftspear - Zangarmarsh" } },

        { type = "header", label = "350 - 360" },

        { type = "step", low = 350, high = 360,
          output = { { name = "Adamantite Weightstone", qty = 45 } },
          mats = {
              { name = "Adamantite Bar", qty = 45 },
              { name = "Netherweave Cloth", qty = 90 },
          },
          note = "Green for the last 5 points - approximate." },

        { type = "header", label = "360 - 375" },

        { type = "step", low = 360, high = 375,
          output = { { name = "Khorium Belt", qty = 17 } },
          mats = {
              { name = "Khorium Bar", qty = 51 },
              { name = "Primal Water", qty = 34 },
              { name = "Primal Mana", qty = 34 },
          },
          note = "Plans: Khorium Belt drops from Murkblood Raiders in Nagrand (no reputation needed - may take a while to drop). Alternatives if you'd rather go a different route: Enchanted Adamantite Belt (needs Friendly with The Scryers), Felsteel Gloves (farmed from Auchenai Monks in Auchenai Crypts), or Flamebane Gloves (needs Honored with The Aldor)." },
    },

    trainers = {
        classic = {
            horde = {
                "Saru Steelfury - Orgrimmar",
                "James Van Brunt - Undercity",
                "Karn Stonehoof - Thunder Bluff",
                "Bemarrin - Silvermoon City",
            },
            alliance = {
                "Bengus Deepforge - Ironforge",
                "Therum Deepforge - Stormwind City",
                "Miall - The Exodar",
            },
        },
        master = {
            horde = {
                "Rohok - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Humphry - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Blacksmithing")
