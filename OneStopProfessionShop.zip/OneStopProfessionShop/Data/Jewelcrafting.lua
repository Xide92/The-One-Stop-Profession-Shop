--[[
    Jewelcrafting leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Jewelcrafting leveling routes.
    This profession has more branching than most (many interchangeable gem
    cuts, reputation-gated recipes, low-droprate rare gems) - one clear path
    was picked per bracket, with the easiest-to-reach alternatives noted.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Jewelcrafting = {

    tools = {
        "Jeweler's Kit - buy from the Jewelcrafting Supply vendor near your trainer or any General/Trade Goods vendor.",
        "Mercurial Stone - needed for one recipe at 325. Jewelcrafters can't make this themselves - buy it from the Auction House, or ask an Alchemist (1 Primal Earth, 1 Primal Life, 1 Primal Mana).",
        "Draenei characters get +5 Jewelcrafting from their Gemcutting racial - recipes stay orange 5 points longer, which saves gold on lower-tier crafts.",
    },

    sections = {
        { type = "header", label = "1 - 50" },

        { type = "step", low = 1, high = 35,
          output = { { name = "Delicate Copper Wire", qty = 55 } },
          mats   = { { name = "Copper Bar", qty = 110 } },
          note = "Keep these - you'll need them again soon. Stop at 35 and only make more if needed." },

        { type = "step", low = 35, high = 50,
          output = { { name = "Tigerseye Band", qty = 15 } },
          mats = {
              { name = "Tigerseye", qty = 15 },
              { name = "Delicate Copper Wire", qty = 15 },
          },
          note = "Malachite Pendant (15 Malachite, 15 Delicate Copper Wire) works just as well if Malachite is cheaper for you." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Jewelcrafting", reqLevel = 10,
          note = "At skill 20 you can also learn Prospecting from your trainer - lets you turn 5 ore into a chance at gems. Worth learning as soon as it's available." },

        { type = "header", label = "50 - 120" },

        { type = "step", low = 50, high = 80,
          output = { { name = "Bronze Setting", qty = 50 } },
          mats   = { { name = "Bronze Bar", qty = 100 } },
          note = "Save these - you'll need some later." },

        { type = "step", low = 80, high = 100,
          output = { { name = "Gloom Band", qty = 20 } },
          mats = {
              { name = "Bronze Setting", qty = 20 },
              { name = "Shadowgem", qty = 40 },
              { name = "Delicate Copper Wire", qty = 40 },
          },
          note = "Simple Pearl Ring (Small Lustrous Pearl) or Ring of Silver Might (Silver Bar only) work as substitutes if Shadowgem is expensive." },

        { type = "step", low = 100, high = 110,
          output = { { name = "Ring of Twilight Shadows", qty = 10 } },
          mats = {
              { name = "Shadowgem", qty = 20 },
              { name = "Bronze Bar", qty = 20 },
          } },

        { type = "step", low = 110, high = 120,
          output = { { name = "Heavy Stone Statue", qty = 10 } },
          mats   = { { name = "Heavy Stone", qty = 80 } },
          note = "If Heavy Stone is cheap, you can keep making these up to 130 instead of moving on." },

        { type = "header", label = "120 - 150" },

        { type = "buy", name = "Design: Pendant of the Agate Shield",
          note = "Not taught by any trainer - must be bought. Limited supply (5-10 min respawn); check the Auction House if the vendor is sold out.",
          vendors = { "Jandia - Thousand Needles (Freewind Post, Horde)", "Neal Allen - Wetlands (Menethil Harbor, Alliance)" } },

        { type = "step", low = 120, high = 150,
          output = { { name = "Pendant of the Agate Shield", qty = 30 } },
          mats = {
              { name = "Moss Agate", qty = 30 },
              { name = "Bronze Setting", qty = 30 },
          },
          note = "If both recipe vendors are camped out, Heavy Jade Ring (120-136, needs Jade) then Golden Dragon Ring (136-150, needs Jade + Gold Bar) is a trainer-taught fallback." },

        { type = "rankup", atSkill = 150, rank = "Expert Jewelcrafting", reqLevel = 20 },

        { type = "header", label = "150 - 225" },

        { type = "step", low = 150, high = 180,
          output = { { name = "Mithril Filigree", qty = 71 } },
          mats   = { { name = "Mithril Bar", qty = 142 } },
          note = "Keep these - needed again at 185-210. Goes yellow near the end; making 55-60 of them is enough to move on." },

        { type = "step", low = 180, high = 185,
          output = { { name = "Solid Stone Statue", qty = 9 } },
          mats   = { { name = "Solid Stone", qty = 90 } } },

        { type = "step", low = 185, high = 210,
          output = { { name = "Engraved Truesilver Ring", qty = 28 } },
          mats = {
              { name = "Truesilver Bar", qty = 28 },
              { name = "Mithril Filigree", qty = 56 },
          },
          note = "Yellow near the end - may need a few extra." },

        { type = "step", low = 210, high = 220,
          output = { { name = "Aquamarine Signet", qty = 10 } },
          mats = {
              { name = "Aquamarine", qty = 30 },
              { name = "Flask of Mojo", qty = 40 },
          } },

        { type = "step", low = 220, high = 225,
          output = { { name = "Aquamarine Pendant of the Warrior", qty = 5 } },
          mats = {
              { name = "Aquamarine", qty = 5 },
              { name = "Mithril Filigree", qty = 15 },
          } },

        { type = "rankup", atSkill = 225, rank = "Artisan Jewelcrafting", reqLevel = 35 },

        { type = "header", label = "225 - 300" },

        { type = "step", low = 225, high = 250,
          output = { { name = "Thorium Setting", qty = 56 } },
          mats   = { { name = "Thorium Bar", qty = 56 } },
          note = "Stop at 250 and only make more later if you need them for the recipes below." },

        { type = "step", low = 250, high = 260,
          output = { { name = "Ruby Pendant of Fire", qty = 10 } },
          mats = {
              { name = "Star Ruby", qty = 10 },
              { name = "Thorium Setting", qty = 10 },
          } },

        { type = "step", low = 260, high = 281,
          output = { { name = "Simple Opal Ring", qty = 21 } },
          mats = {
              { name = "Large Opal", qty = 21 },
              { name = "Thorium Setting", qty = 21 },
          } },

        { type = "step", low = 281, high = 295,
          output = { { name = "Diamond Focus Ring", qty = 20 } },
          mats = {
              { name = "Azerothian Diamond", qty = 20 },
              { name = "Thorium Setting", qty = 20 },
          } },

        { type = "step", low = 295, high = 300,
          output = { { name = "Emerald Lion Ring", qty = 5 } },
          mats = {
              { name = "Huge Emerald", qty = 10 },
              { name = "Thorium Setting", qty = 5 },
          } },

        { type = "rankup", atSkill = 300, rank = "Master Jewelcrafting (Outland)", reqLevel = 55,
          note = "Higher level requirement than most other Master ranks - you need to be 55, not 50." },

        { type = "header", label = "300 - 320" },

        { type = "step", low = 300, high = 320,
          output = { { name = "Solid Azure Moonstone", qty = 30 } },
          mats   = { { name = "Azure Moonstone", qty = 30 } },
          note = "Any of the six basic uncommon gem cuts (Blood Garnet, Shadow Draenite, Golden Draenite, Deep Peridot, Azure Moonstone, Flame Spessarite) work identically - use whichever raw gem is cheapest. Recipes sold by your Outland trainer." },

        { type = "header", label = "320 - 325" },

        { type = "step", low = 320, high = 325,
          output = { { name = "Bright Blood Garnet", qty = 6 } },
          mats   = { { name = "Blood Garnet", qty = 6 } },
          note = "Same deal - any of the four upgraded cuts work the same. Sold by your Outland trainer." },

        { type = "header", label = "325 - 335" },

        { type = "step", low = 325, high = 335,
          output = { { name = "Mercurial Adamantite", qty = 12 } },
          mats = {
              { name = "Adamantite Powder", qty = 48 },
              { name = "Primal Earth", qty = 12 },
          },
          note = "48 Adamantite Powder comes from prospecting 240 Adamantite Ore. Keep all 12 Mercurial Adamantite - needed again at 340. Requires the Mercurial Stone tool (see Required Tools above)." },

        { type = "header", label = "335 - 340" },

        { type = "step", low = 335, high = 340,
          output = { { name = "Smooth Golden Draenite", qty = 7 } },
          mats   = { { name = "Golden Draenite", qty = 7 } },
          note = "Sold by your Outland trainer, no reputation needed (unlike the Flame Spessarite alternative, which needs Lower City rep)." },

        { type = "header", label = "340 - 350" },

        { type = "step", low = 340, high = 350,
          output = { { name = "Heavy Adamantite Ring", qty = 12 } },
          mats = {
              { name = "Adamantite Bar", qty = 12 },
              { name = "Mercurial Adamantite", qty = 12 },
          } },

        { type = "header", label = "350 - 360" },

        { type = "step", low = 350, high = 360,
          output = { { name = "Purified Shadow Pearl", qty = 15 } },
          mats = {
              { name = "Shadow Pearl", qty = 15 },
              { name = "Purified Draenic Water", qty = 15 },
          },
          note = "Shadow Pearl has a low drop rate from Jaggal Clams - buying off the Auction House is usually faster than farming. If your faction controls Halaa in Nagrand, Mystic Dawnstone or Steady Talasite are cheap trainer-sold alternatives." },

        { type = "header", label = "360 - 375" },

        { type = "step", low = 360, high = 375,
          output = { { name = "Insightful Earthstorm Diamond", qty = 10 } },
          mats   = { { name = "Earthstorm Diamond", qty = 10 } },
          note = "Recipe sold by Almaador in Shattrath City (Friendly with The Sha'tar - low bar). This carries you the rest of the way; if you'd rather not wait on that reputation, just keep crafting the 340 or 335 bracket's gems a few more times instead." },
    },

    trainers = {
        classic = {
            horde = {
                "Kalinda - Silvermoon City",
            },
            alliance = {
                "Farii - The Exodar",
            },
        },
        master = {
            horde = {
                "Kalaen - Hellfire Peninsula (Thrallmar)",
            },
            alliance = {
                "Tatiana - Hellfire Peninsula (Honor Hold)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Jewelcrafting")
