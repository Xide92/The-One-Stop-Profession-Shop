--[[
    First Aid leveling data for KyroProfGuide.
    Compiled from standard TBC Classic First Aid leveling routes.
    A secondary profession - doesn't take one of your two profession slots,
    every character can learn it. Skill numbers are approximate breakpoints -
    actual skill-ups vary with luck (green/yellow/orange).
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData["First Aid"] = {

    tools = {
        "No tools required - just cloth and your bare hands.",
        "Secondary profession - doesn't use one of your two profession slots, every character can learn this alongside Cooking and Fishing.",
    },

    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 40,
          output = { { name = "Linen Bandage", qty = 50 } },
          mats   = { { name = "Linen Cloth", qty = 50 } } },

        { type = "step", low = 40, high = 75,
          output = { { name = "Heavy Linen Bandage", qty = 45 } },
          mats   = { { name = "Linen Cloth", qty = 90 } } },

        { type = "rankup", atSkill = 75, rank = "Journeyman First Aid", reqLevel = 10 },

        { type = "header", label = "75 - 150" },

        { type = "step", low = 75, high = 80,
          output = { { name = "Heavy Linen Bandage", qty = 20 } },
          mats   = { { name = "Linen Cloth", qty = 40 } } },

        { type = "step", low = 80, high = 115,
          output = { { name = "Wool Bandage", qty = 60 } },
          mats   = { { name = "Wool Cloth", qty = 60 } } },

        { type = "step", low = 115, high = 150,
          output = { { name = "Heavy Wool Bandage", qty = 60 } },
          mats   = { { name = "Wool Cloth", qty = 120 } },
          note = "Learn the Silk Bandage recipe from your trainer before you leave for the next bracket." },

        { type = "buy", name = "Expert First Aid - Under Wraps / Manual: Heavy Silk Bandage / Manual: Mageweave Bandage",
          note = "Buy all three before you reach 150 - this is how you train past 150, there's no trainer for it. Right-click the book to learn it.",
          vendors = { "Deneb Walker - Arathi Highlands (Alliance)", "Balai Lok'Wein - Dustwallow Marsh (Horde)" } },

        { type = "header", label = "150 - 225" },

        { type = "step", low = 150, high = 180,
          output = { { name = "Silk Bandage", qty = 50 } },
          mats   = { { name = "Silk Cloth", qty = 50 } } },

        { type = "step", low = 180, high = 210,
          output = { { name = "Heavy Silk Bandage", qty = 50 } },
          mats   = { { name = "Silk Cloth", qty = 100 } },
          note = "Requires the Manual: Heavy Silk Bandage bought earlier." },

        { type = "step", low = 210, high = 225,
          output = { { name = "Mageweave Bandage", qty = 30 } },
          mats   = { { name = "Mageweave Cloth", qty = 30 } },
          note = "Requires the Manual: Mageweave Bandage bought earlier." },

        { type = "rankup", atSkill = 225, rank = "Artisan First Aid", reqLevel = 35,
          note = "Requires completing the Triage quest chain instead of simple training - Alliance: Trauma then Triage from Doctor Gustaf VanHowzen (Dustwallow Marsh, Theramore Isle). Horde: from Doctor Gregory Victor (Arathi Highlands, Hammerfall). Bring ~100 Mageweave Cloth and 70 Runecloth - the quest giver teaches you several bandage recipes on the spot once you finish." },

        { type = "header", label = "225 - 300" },

        { type = "step", low = 225, high = 240,
          output = { { name = "Mageweave Bandage", qty = 30 } },
          mats   = { { name = "Mageweave Cloth", qty = 30 } } },

        { type = "step", low = 240, high = 260,
          output = { { name = "Heavy Mageweave Bandage", qty = 30 } },
          mats   = { { name = "Mageweave Cloth", qty = 60 } },
          note = "Taught by the Triage quest giver at this skill level - talk to them again." },

        { type = "step", low = 260, high = 290,
          output = { { name = "Runecloth Bandage", qty = 50 } },
          mats   = { { name = "Runecloth", qty = 50 } },
          note = "Taught by the Triage quest giver at this skill level - talk to them again." },

        { type = "step", low = 290, high = 300,
          output = { { name = "Heavy Runecloth Bandage", qty = 15 } },
          mats   = { { name = "Runecloth", qty = 30 } },
          note = "Taught by the Triage quest giver at this skill level - talk to them again." },

        { type = "buy", name = "Master First Aid - Doctor in the House / Manual: Netherweave Bandage / Manual: Heavy Netherweave Bandage",
          note = "There are no First Aid trainers past 300 - buy all three before continuing. Right-click each book to learn it.",
          vendors = { "Aresella - Hellfire Peninsula (Falcon Watch, Horde)", "Burko - Hellfire Peninsula (Temple of Telhamat, Alliance)" } },

        { type = "rankup", atSkill = 300, rank = "Master First Aid (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 330" },

        { type = "step", low = 300, high = 330,
          output = { { name = "Heavy Runecloth Bandage", qty = 70 } },
          mats   = { { name = "Runecloth", qty = 140 } } },

        { type = "header", label = "330 - 360" },

        { type = "step", low = 330, high = 360,
          output = { { name = "Netherweave Bandage", qty = 45 } },
          mats   = { { name = "Netherweave Cloth", qty = 45 } } },

        { type = "header", label = "360 - 375" },

        { type = "step", low = 360, high = 375,
          output = { { name = "Heavy Netherweave Bandage", qty = 20 } },
          mats   = { { name = "Netherweave Cloth", qty = 40 } } },
    },

    trainers = {
        classic = {
            horde = {
                "Arnok - Orgrimmar",
                "Pand Stonebinder - Thunder Bluff",
                "Mary Edras - Undercity",
                "Nurse Neela - Tirisfal Glades",
                "Rawrk - Durotar",
                "Vira Younghoof - Mulgore",
                "Alestus - Silvermoon City",
            },
            alliance = {
                "Shaina Fuller - Stormwind City",
                "Dannelor - Darnassus",
                "Nissa Firestone - Ironforge",
                "Michelle Belle - Elwynn Forest",
                "Byancie - Teldrassil",
                "Thamner Pol - Dun Morogh",
                "Nus - The Exodar",
            },
        },
        master = {
            horde = { "No trainer - buy the book from Aresella (Hellfire Peninsula, Falcon Watch)" },
            alliance = { "No trainer - buy the book from Burko (Hellfire Peninsula, Temple of Telhamat)" },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "First Aid")
