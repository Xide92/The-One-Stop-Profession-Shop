--[[
    Cooking leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Cooking leveling routes.
    Cooking almost always offers several valid recipes per bracket - one was
    picked per bracket (favoring trainer-taught or single-vendor-trip options
    over quest chains or faction-locked recipes), with alternatives noted.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Cooking = {

    tools = {
        "No permanent tools required - just a nearby fire (or a Portable Cooking Fire, sold by Cooking Supply vendors) to cook at.",
        "Secondary profession - doesn't use one of your two profession slots, every character can learn this alongside First Aid and Fishing.",
    },

    sections = {
        { type = "header", label = "1 - 65" },

        { type = "step", low = 1, high = 40,
          output = { { name = "Spice Bread", qty = 60 } },
          mats = {
              { name = "Simple Flour", qty = 60 },
              { name = "Mild Spices", qty = 60 },
          },
          note = "Don't buy these off the Auction House - both are cheap at any Cooking Supply vendor." },

        { type = "step", low = 40, high = 65,
          output = { { name = "Roasted Boar Meat", qty = 35 } },
          mats   = { { name = "Chunk of Boar Meat", qty = 35 } },
          note = "Trainer-taught, no extra vendor trip needed. Smoked Bear Meat, Spiced Wolf Meat, or a cooking-fish recipe work just as well if you have the ingredients already." },

        { type = "rankup", atSkill = 50, rank = "Journeyman Cooking", reqLevel = 10 },

        { type = "header", label = "65 - 130" },

        { type = "step", low = 65, high = 110,
          output = { { name = "Coyote Steak", qty = 65 } },
          mats   = { { name = "Coyote Meat", qty = 65 } },
          note = "Trainer-taught. Boiled Clams, Longjaw Mud Snapper, or Strider Stew (Horde only) work just as well - use whichever meat/fish you have piling up." },

        { type = "step", low = 110, high = 130,
          output = { { name = "Crab Cake", qty = 30 } },
          mats = {
              { name = "Crawler Meat", qty = 30 },
              { name = "Mild Spices", qty = 30 },
          },
          note = "Trainer-taught. Dry Pork Ribs is an equally good trainer-taught alternative if Boar Ribs are more available to you." },

        { type = "buy", name = "Expert Cookbook",
          note = "Buy before you reach 150 - this is how you train past 150, there's no trainer for it.",
          vendors = { "Wulan - Desolace (Shadowprey Village, Horde)", "Shandrina - Ashenvale (Alliance)" } },

        { type = "header", label = "130 - 225" },

        { type = "step", low = 130, high = 175,
          output = { { name = "Curiously Tasty Omelet", qty = 50 } },
          mats   = { { name = "Raptor Egg", qty = 50 } },
          note = "Recipe sold by Kendor Kabonka (Stormwind, Alliance) or Keena (Arathi Highlands, Horde)." },

        { type = "step", low = 175, high = 225,
          output = { { name = "Roast Raptor", qty = 50 } },
          mats   = { { name = "Raptor Flesh", qty = 50 } },
          note = "Recipe sold by Hammon Karwn (Alliance) or Keena (Horde), both in Arathi Highlands." },

        { type = "rankup", atSkill = 225, rank = "Artisan Cooking", reqLevel = 35,
          note = "Requires the Clamlette Surprise quest chain instead of simple training. Horde starts with 'To Gadgetzan You Go!' from Zamja in Orgrimmar; Alliance starts with 'I Know A Guy...' from Daryl Riknussun in Ironforge. Both lead to Dirge Quikcleave in Gadgetzan, who wants 12 Giant Egg, 10 Zesty Clam Meat, and 20 Alterac Swiss to finish it." },

        { type = "header", label = "225 - 250" },

        { type = "step", low = 225, high = 250,
          output = { { name = "Spotted Yellowtail", qty = 25 } },
          mats   = { { name = "Raw Spotted Yellowtail", qty = 25 } },
          note = "Recipe sold by Gikkix in Tanaris - buy every recipe he sells while you're there, you'll want more of them soon. Undermine Clam Chowder, Monster Omelet, Tender Wolf Steak, and Filet of Redgill all work identically if you have those ingredients instead." },

        { type = "header", label = "250 - 285" },

        { type = "step", low = 250, high = 285,
          output = { { name = "Poached Sunscale Salmon", qty = 40 } },
          mats   = { { name = "Raw Sunscale Salmon", qty = 40 } },
          note = "Also sold by Gikkix in Tanaris. Juicy Bear Burger and Nightfin Soup are fine alternatives if you'd rather use those ingredients." },

        { type = "header", label = "285 - 300" },

        { type = "step", low = 285, high = 300,
          output = { { name = "Baked Salmon", qty = 15 } },
          mats   = { { name = "Raw Whitescale Salmon", qty = 15 } },
          note = "Recipe sold by Vivianna (Alliance) or Sheendra Tallgrass (Horde) in Feralas - no quest chain needed, unlike the Smoked Desert Dumplings alternative (which requires two quests in Silithus)." },

        { type = "buy", name = "Master Cookbook",
          note = "There are no Cooking trainers past 300 - buy this before continuing.",
          vendors = { "Baxter - Hellfire Peninsula (Thrallmar, Horde)", "Gaston - Hellfire Peninsula (Honor Hold, Alliance)" } },

        { type = "rankup", atSkill = 300, rank = "Master Cooking (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          output = { { name = "Ravager Dog", qty = 30 } },
          mats   = { { name = "Ravager Flesh", qty = 30 } },
          note = "Recipe sold by Cookie One-Eye (Horde) or Sid Limbardi (Alliance) in Hellfire Peninsula - simpler than the Buzzard Bites alternative, which needs a 3-quest chain." },

        { type = "header", label = "325 - 355" },

        { type = "step", low = 325, high = 355,
          output = { { name = "Talbuk Steak", qty = 40 } },
          mats   = { { name = "Talbuk Venison", qty = 40 } },
          note = "Recipe sold by Nula the Butcher (Horde) or Uriku (Alliance), both in Nagrand. Roasted Clefthoof (same vendors) or Warp Burger (different vendor in Terokkar Forest) work just as well." },

        { type = "header", label = "355 - 375" },

        { type = "step", low = 355, high = 375,
          output = { { name = "Crunchy Serpent", qty = 60 } },
          mats   = { { name = "Serpent Flesh", qty = 60 } },
          note = "Horde: Xerintha Ravenoak in Blade's Edge Mountains (Ruuan Weald) - limited supply; the Mok'Nathal Treats quest is a faster fallback if she's sold out. Alliance: Sassa Weldwell in Blade's Edge Mountains (Toshley's Station) sells it in unlimited supply - always buy from her." },
    },

    trainers = {
        classic = {
            horde = {
                "Zamja - Orgrimmar",
                "Eunice Burch - Undercity",
                "Aska Mistrunner - Thunder Bluff",
                "Duhng - The Barrens",
                "Mudduk - Stranglethorn Vale",
                "Pyall Silentstride - Mulgore",
                "Sylann - Silvermoon City",
            },
            alliance = {
                "Stephen Ryback - Stormwind City",
                "Daryl Riknussun - Ironforge",
                "Alegorn - Darnassus",
                "Gremlock Pilsnor - Dun Morogh",
                "Tomas - Elwynn Forest",
                "Zarrin - Teldrassil",
                "Mumman - The Exodar",
            },
        },
        master = {
            horde = { "No trainer - buy the Master Cookbook from Baxter (Hellfire Peninsula, Thrallmar)" },
            alliance = { "No trainer - buy the Master Cookbook from Gaston (Hellfire Peninsula, Honor Hold)" },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Cooking")
