--[[
    Leatherworking leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Leatherworking leveling routes.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck (green/yellow/orange).
    Where the source guide offers multiple valid recipes, the option with the
    fewest outside dependencies (rare drops, reputation, quests) was picked as
    the main route, with alternatives noted.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Leatherworking = {

    tools = {
        "No permanent tools required - threads, dyes, and salt are all bought from the Leatherworking Supply vendor near your trainer.",
    },

    sections = {
        { type = "header", label = "1 - 55" },

        { type = "step", low = 1, high = 20,
          output = { { name = "Light Leather", qty = 19 } },
          mats   = { { name = "Ruined Leather Scraps", qty = 57 } },
          note = "If you have no Ruined Leather Scraps, skip straight to Light Armor Kit instead." },

        { type = "step", low = 20, high = 45,
          output = { { name = "Light Armor Kit", qty = 40 } },
          mats   = { { name = "Light Leather", qty = 40 } } },

        { type = "step", low = 45, high = 55,
          output = { { name = "Handstitched Leather Cloak", qty = 20 } },
          mats = {
              { name = "Light Leather", qty = 40 },
              { name = "Coarse Thread", qty = 20 },
          } },

        { type = "rankup", atSkill = 55, rank = "Journeyman Leatherworking", reqLevel = 10 },

        { type = "header", label = "55 - 135" },

        { type = "step", low = 55, high = 100,
          output = { { name = "Embossed Leather Gloves", qty = 50 } },
          mats = {
              { name = "Light Leather", qty = 150 },
              { name = "Coarse Thread", qty = 100 },
          } },

        { type = "step", low = 100, high = 120,
          output = { { name = "Fine Leather Belt", qty = 25 } },
          mats = {
              { name = "Light Leather", qty = 150 },
              { name = "Coarse Thread", qty = 50 },
          } },

        { type = "step", low = 120, high = 135,
          output = { { name = "Dark Leather Boots", qty = 20 } },
          mats = {
              { name = "Medium Leather", qty = 80 },
              { name = "Fine Thread", qty = 40 },
              { name = "Gray Dye", qty = 20 },
          } },

        { type = "rankup", atSkill = 135, rank = "Expert Leatherworking", reqLevel = 20 },

        { type = "header", label = "135 - 155" },

        { type = "step", low = 135, high = 150,
          output = { { name = "Dark Leather Pants", qty = 25 } },
          mats = {
              { name = "Medium Leather", qty = 300 },
              { name = "Gray Dye", qty = 25 },
              { name = "Fine Thread", qty = 25 },
          } },

        { type = "step", low = 150, high = 155,
          output = { { name = "Heavy Leather", qty = 7 } },
          mats   = { { name = "Medium Leather", qty = 35 } } },

        { type = "header", label = "155 - 205" },

        { type = "step", low = 155, high = 165,
          output = { { name = "Cured Heavy Hide", qty = 20 } },
          mats = {
              { name = "Heavy Hide", qty = 20 },
              { name = "Salt", qty = 60 },
          },
          note = "Heavy Hide has a low drop rate. If you can't get any, skip this step and make Heavy Armor Kit for the whole 155-200 stretch instead (no hide needed)." },

        { type = "step", low = 165, high = 180,
          output = { { name = "Heavy Armor Kit", qty = 15 } },
          mats = {
              { name = "Heavy Leather", qty = 75 },
              { name = "Fine Thread", qty = 15 },
          } },

        { type = "step", low = 180, high = 190,
          output = { { name = "Barbaric Shoulders", qty = 10 } },
          mats = {
              { name = "Heavy Leather", qty = 80 },
              { name = "Cured Heavy Hide", qty = 10 },
              { name = "Fine Thread", qty = 20 },
          } },

        { type = "step", low = 190, high = 200,
          output = { { name = "Guardian Gloves", qty = 10 } },
          mats = {
              { name = "Heavy Leather", qty = 40 },
              { name = "Cured Heavy Hide", qty = 10 },
              { name = "Silken Thread", qty = 10 },
          } },

        { type = "step", low = 200, high = 205,
          output = { { name = "Thick Armor Kit", qty = 5 } },
          mats = {
              { name = "Thick Leather", qty = 25 },
              { name = "Silken Thread", qty = 5 },
          } },

        { type = "rankup", atSkill = 205, rank = "Artisan Leatherworking", reqLevel = 35 },

        { type = "header", label = "205 - 300" },

        { type = "step", low = 205, high = 235,
          output = { { name = "Nightscape Headband", qty = 40 } },
          mats = {
              { name = "Thick Leather", qty = 200 },
              { name = "Silken Thread", qty = 80 },
          },
          note = "At skill 225 + character level 40 you can pick a specialization (Dragonscale, Elemental, or Tribal) - optional, doesn't affect leveling." },

        { type = "step", low = 235, high = 250,
          output = { { name = "Nightscape Pants", qty = 15 } },
          mats = {
              { name = "Thick Leather", qty = 210 },
              { name = "Silken Thread", qty = 60 },
          } },

        { type = "step", low = 250, high = 265,
          output = { { name = "Rugged Armor Kit", qty = 25 } },
          mats   = { { name = "Rugged Leather", qty = 125 } } },

        { type = "step", low = 265, high = 290,
          output = { { name = "Wicked Leather Bracers", qty = 28 } },
          mats = {
              { name = "Rugged Leather", qty = 224 },
              { name = "Black Dye", qty = 28 },
              { name = "Rune Thread", qty = 28 },
          } },

        { type = "step", low = 290, high = 300,
          output = { { name = "Wicked Leather Headband", qty = 10 } },
          mats = {
              { name = "Rugged Leather", qty = 120 },
              { name = "Black Dye", qty = 10 },
              { name = "Rune Thread", qty = 10 },
          } },

        { type = "rankup", atSkill = 300, rank = "Master Leatherworking (Outland)", reqLevel = 50 },

        { type = "header", label = "300 - 325" },

        { type = "step", low = 300, high = 325,
          output = { { name = "Knothide Armor Kit", qty = 30 } },
          mats   = { { name = "Knothide Leather", qty = 120 } },
          note = "Goes yellow - may need a few extra." },

        { type = "buy", name = "Pattern: Heavy Knothide Leather",
          note = "Buy before you reach 325. Limited supply, restocks every 2-6 minutes.",
          vendors = { "Cro Threadstrong - Shattrath City" } },

        { type = "header", label = "325 - 335" },

        { type = "step", low = 325, high = 335,
          output = { { name = "Heavy Knothide Leather", qty = 222 } },
          mats   = { { name = "Knothide Leather", qty = 1110 } },
          note = "Can stop at 335 and craft the rest later when you actually need them for gear." },

        { type = "header", label = "335 - 350" },

        { type = "step", low = 335, high = 350,
          output = { { name = "Thick Draenic Vest", qty = 20 } },
          mats = {
              { name = "Knothide Leather", qty = 280 },
              { name = "Rune Thread", qty = 60 },
          },
          note = "Yellow for the last 10 points - may need a few extra." },

        { type = "header", label = "350 - 365" },

        { type = "step", low = 350, high = 365,
          output = { { name = "Heavy Knothide Armor Kit", qty = 50 } },
          mats   = { { name = "Heavy Knothide Leather", qty = 150 } },
          note = "Green for the last 5 points - usually needs 35-60 total, not exactly 50." },

        { type = "buy", name = "Recipe: Drums of Battle",
          note = "Buy before you reach 365. Requires Honored reputation with The Sha'tar.",
          vendors = { "Almaador - Shattrath City" } },

        { type = "header", label = "365 - 375" },

        { type = "step", low = 365, high = 375,
          output = { { name = "Drums of Battle", qty = 12 } },
          mats = {
              { name = "Heavy Knothide Leather", qty = 72 },
              { name = "Thick Clefthoof Leather", qty = 48 },
          },
          note = "This single recipe carries the whole 365-375 stretch - it just goes green for the last few points, so budget a couple extra crafts. Drums of Panic (Fel Hide instead of Thick Clefthoof Leather) is a fine swap if you'd rather grind Keepers of Time reputation instead of Sha'tar - sold by Alurmi inside Caverns of Time, Honored required." },
    },

    trainers = {
        classic = {
            horde = {
                "Karolek - Orgrimmar",
                "Arthur Moore - Undercity",
                "Una - Thunder Bluff",
                "Lynalis - Silvermoon City",
            },
            alliance = {
                "Simon Tanner - Stormwind City",
                "Fimble Finespindle - Ironforge",
                "Telonis - Darnassus",
                "Akham - The Exodar",
            },
        },
        master = {
            horde = {
                "Barim Spilthoof - Hellfire Peninsula (Thrallmar)",
                "Darmari - Shattrath City (either faction)",
            },
            alliance = {
                "Brumman - Hellfire Peninsula (Honor Hold)",
                "Darmari - Shattrath City (either faction)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Leatherworking")
