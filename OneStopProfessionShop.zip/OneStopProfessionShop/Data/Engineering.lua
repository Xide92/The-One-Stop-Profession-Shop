--[[
    Engineering leveling data for KyroProfGuide.
    Compiled from standard TBC Classic Engineering leveling routes.
    Skill numbers are approximate breakpoints - actual skill-ups vary with luck (green/yellow/orange).

    output/mats use structured {name, qty} lists (instead of free text) so the
    addon can total up a shopping list and check your bags against it.
]]

KyroProfGuideData = KyroProfGuideData or {}

KyroProfGuideData.Engineering = {

    tools = {
        "Arclight Spanner - required for most Engineering crafts (you craft your own at skill ~50)",
        "Gyromatic Micro-Adjustor - required for higher-level recipes (you craft your own at skill ~194)",
    },

    -- Ordered list of sections. type = "header" | "step" | "rankup" | "buy"
    sections = {
        { type = "header", label = "1 - 75" },

        { type = "step", low = 1, high = 30,
          output = { { name = "Rough Blasting Powder", qty = 60 } },
          mats   = { { name = "Rough Stone", qty = 60 } },
          note = "You may reach ~40 with this alone. Keep the leftovers, you'll need them again later." },

        { type = "step", low = 30, high = 50,
          output = { { name = "Handful of Copper Bolts", qty = 30 } },
          mats   = { { name = "Copper Bar", qty = 30 } },
          note = "Keep about 30 of these for the next step." },

        { type = "step", low = 50, high = 51,
          output = { { name = "Arclight Spanner", qty = 1 } },
          mats   = { { name = "Copper Bar", qty = 6 } },
          note = "This is a permanent tool, not consumed when crafting. Keep it on you at all times." },

        { type = "step", low = 51, high = 75,
          output = { { name = "Rough Copper Bomb", qty = 30 } },
          mats = {
              { name = "Copper Bar", qty = 30 },
              { name = "Handful of Copper Bolts", qty = 30 },
              { name = "Rough Blasting Powder", qty = 60 },
              { name = "Linen Cloth", qty = 30 },
          },
          note = "This uses up the Rough Blasting Powder and Copper Bolts from the earlier steps." },

        { type = "rankup", atSkill = 75, rank = "Journeyman Engineering", reqLevel = 10 },

        { type = "header", label = "75 - 135" },

        { type = "step", low = 75, high = 90,
          output = { { name = "Coarse Blasting Powder", qty = 60 } },
          mats   = { { name = "Coarse Stone", qty = 60 } },
          note = "Keep these for later." },

        { type = "step", low = 90, high = 100,
          output = { { name = "Coarse Dynamite", qty = 20 } },
          mats = {
              { name = "Coarse Blasting Powder", qty = 60 },
              { name = "Linen Cloth", qty = 20 },
          } },

        { type = "step", low = 100, high = 105,
          output = { { name = "Silver Contact", qty = 5 } },
          mats   = { { name = "Silver Bar", qty = 5 } },
          note = "If Silver Bar is expensive, craft Flying Tiger Goggles instead for the same skill-ups." },

        { type = "step", low = 105, high = 125,
          output = { { name = "Bronze Tube", qty = 25 } },
          mats = {
              { name = "Bronze Bar", qty = 50 },
              { name = "Weak Flux", qty = 25 },
          },
          note = "Weak Flux is sold by the Engineering Supply vendor near your trainer." },

        { type = "step", low = 125, high = 135,
          output = { { name = "Standard Scope", qty = 10 } },
          mats = {
              { name = "Bronze Tube", qty = 10 },
              { name = "Moss Agate", qty = 10 },
          },
          note = "If Moss Agate is too expensive, start making Heavy Blasting Powder instead." },

        { type = "rankup", atSkill = 150, rank = "Expert Engineering", reqLevel = 20 },

        { type = "header", label = "135 - 200" },

        { type = "step", low = 135, high = 150,
          recipes = {
              { output = { name = "Heavy Blasting Powder", qty = 30 },
                mats = { { name = "Heavy Stone", qty = 30 } } },
              { output = { name = "Whirring Bronze Gizmo", qty = 15 },
                mats = { { name = "Bronze Bar", qty = 30 }, { name = "Wool Cloth", qty = 15 } } },
          },
          note = "You'll need both of these again later, so keep them rather than using them right away." },

        { type = "step", low = 150, high = 160,
          output = { { name = "Bronze Framework", qty = 15 } },
          mats = {
              { name = "Bronze Bar", qty = 30 },
              { name = "Medium Leather", qty = 15 },
              { name = "Wool Cloth", qty = 15 },
          },
          note = "Keep these too - used in the next step." },

        { type = "step", low = 160, high = 175,
          output = { { name = "Explosive Sheep", qty = 15 } },
          mats = {
              { name = "Heavy Blasting Powder", qty = 30 },
              { name = "Whirring Bronze Gizmo", qty = 15 },
              { name = "Bronze Framework", qty = 15 },
              { name = "Wool Cloth", qty = 30 },
          },
          note = "Keep 5 spare if you're planning to pick Goblin Engineering at 200." },

        { type = "step", low = 175, high = 194,
          output = { { name = "Solid Blasting Powder", qty = 60 } },
          mats   = { { name = "Solid Stone", qty = 120 } },
          note = "Save these, you'll need them again around 285." },

        { type = "step", low = 194, high = 195,
          output = { { name = "Gyromatic Micro-Adjustor", qty = 1 } },
          mats   = { { name = "Steel Bar", qty = 4 } },
          note = "A permanent tool, not consumed. Keep it on you." },

        { type = "step", low = 195, high = 200,
          output = { { name = "Mithril Tube", qty = 7 } },
          mats   = { { name = "Mithril Bar", qty = 21 } },
          note = "Keep 6 spare if you're planning to pick Gnomish Engineering at 200." },

        { type = "rankup", atSkill = 200, rank = "Artisan Engineering", reqLevel = 35,
          note = "This is also where you choose a specialization: Gnomish (utility gadgets) or Goblin (bigger booms). It only changes your recipe options, not this leveling route." },

        { type = "header", label = "200 - 300" },

        { type = "step", low = 200, high = 215,
          output = { { name = "Unstable Trigger", qty = 20 } },
          mats = {
              { name = "Mithril Bar", qty = 20 },
              { name = "Mageweave Cloth", qty = 20 },
              { name = "Solid Blasting Powder", qty = 20 },
          },
          note = "Save these for the Hi-Explosive Bomb step." },

        { type = "step", low = 215, high = 238,
          output = { { name = "Mithril Casing", qty = 40 } },
          mats   = { { name = "Mithril Bar", qty = 120 } },
          note = "Save these too." },

        { type = "step", low = 238, high = 250,
          output = { { name = "Hi-Explosive Bomb", qty = 20 } },
          mats = {
              { name = "Mithril Casing", qty = 40 },
              { name = "Unstable Trigger", qty = 20 },
              { name = "Solid Blasting Powder", qty = 40 },
          } },

        { type = "step", low = 250, high = 260,
          output = { { name = "Dense Blasting Powder", qty = 30 } },
          mats   = { { name = "Dense Stone", qty = 60 } },
          note = "Keep at least 15 of these for the 285 step." },

        { type = "step", low = 260, high = 285,
          output = { { name = "Thorium Widget", qty = 35 } },
          mats = {
              { name = "Thorium Bar", qty = 105 },
              { name = "Runecloth", qty = 35 },
          },
          note = "This goes yellow near the end - you may need a few extra." },

        { type = "step", low = 285, high = 300,
          output = { { name = "Thorium Shells", qty = 15 } },
          mats = {
              { name = "Thorium Bar", qty = 30 },
              { name = "Dense Blasting Powder", qty = 15 },
          } },

        { type = "rankup", atSkill = 300, rank = "Master Engineering (Outland)", reqLevel = 50,
          note = "Must be trained from a Master Engineering trainer in Outland - see Trainers below." },

        { type = "header", label = "300 - 320" },

        { type = "step", low = 300, high = 320,
          recipes = {
              { output = { name = "Handful of Fel Iron Bolts", qty = 114 },
                mats = { { name = "Fel Iron Bar", qty = 114 } } },
              { output = { name = "Elemental Blasting Powder", qty = 20 },
                mats = { { name = "Mote of Fire", qty = 20 }, { name = "Mote of Earth", qty = 40 } } },
              { output = { name = "Fel Iron Casing", qty = 52 },
                mats = { { name = "Fel Iron Bar", qty = 156 } } },
          },
          note = "Craft all three now - you'll need every bit of it in the steps below." },

        { type = "header", label = "320 - 325" },

        { type = "step", low = 320, high = 325,
          output = { { name = "Fel Iron Bomb", qty = 7 } },
          mats = {
              { name = "Fel Iron Casing", qty = 7 },
              { name = "Handful of Fel Iron Bolts", qty = 14 },
              { name = "Elemental Blasting Powder", qty = 7 },
          } },

        { type = "header", label = "325 - 335" },

        { type = "step", low = 325, high = 335,
          output = { { name = "Adamantite Frame", qty = 30 } },
          mats = {
              { name = "Adamantite Bar", qty = 120 },
              { name = "Primal Earth", qty = 30 },
          },
          note = "Stop at 335 and save the rest for the 360-370 step." },

        { type = "buy", name = "Schematic: White Smoke Flare",
          note = "Buy this before you reach 335 - it's a limited-supply vendor item (7-10 min respawn).",
          vendors = {
              "Wind Trader Lathrai - Shattrath City",
              "Captured Gnome - Zangarmarsh (Horde)",
              "Feera - The Exodar (Alliance)",
              "Yatheon - Silvermoon City (Horde)",
          } },

        { type = "header", label = "335 - 355" },

        { type = "step", low = 335, high = 355,
          output = { { name = "White Smoke Flare", qty = 70 } },
          mats = {
              { name = "Elemental Blasting Powder", qty = 70 },
              { name = "Netherweave Cloth", qty = 70 },
          },
          note = "Goes green for most of this range, so treat the number as approximate." },

        { type = "buy", name = "Schematic: Adamantite Rifle",
          note = "Grab this at the same time as White Smoke Flare - also limited supply.",
          vendors = {
              "Viggz Shinesparked - Shattrath City",
              "Feera - The Exodar (Alliance)",
              "Yatheon - Silvermoon City (Horde)",
          } },

        { type = "header", label = "355 - 360" },

        { type = "step", low = 355, high = 360,
          output = { { name = "Khorium Power Core", qty = 5 } },
          mats = {
              { name = "Khorium Bar", qty = 15 },
              { name = "Primal Fire", qty = 5 },
          },
          note = "You'll need these at the 370 step - no need to go past 5 here." },

        { type = "header", label = "360 - 370" },

        { type = "step", low = 360, high = 370,
          output = { { name = "Adamantite Rifle", qty = 15 } },
          mats = {
              { name = "Fel Iron Casing", qty = 45 },
              { name = "Adamantite Frame", qty = 30 },
              { name = "Handful of Fel Iron Bolts", qty = 60 },
          },
          note = "May go yellow near the end - craft a few extra if needed." },

        { type = "header", label = "370 - 375" },

        { type = "step", low = 370, high = 375,
          output = { { name = "Field Repair Bot 110G", qty = 5 } },
          mats = {
              { name = "Adamantite Bar", qty = 40 },
              { name = "Handful of Fel Iron Bolts", qty = 40 },
              { name = "Khorium Power Core", qty = 5 },
          },
          note = "Schematic drops from Gan'arg Analyzer mobs in Blade's Edge Mountains (4 groups, high drop chance, won't drop twice)." },
    },

    trainers = {
        classic = {
            horde = {
                "Thund - Orgrimmar",
                "Graham Van Talen - Undercity",
                "Twizwick Sprocketgrind - Mulgore",
                "Mukdrak - Durotar",
                "Danwe - Silvermoon City",
            },
            alliance = {
                "Springspindle Fizzlegear - Ironforge",
                "Lilliam Sparkspindle - Stormwind City",
                "Jenna Lemkenilli - Darkshore",
                "Ockil - The Exodar",
            },
        },
        master = {
            horde = {
                "Zebig - Hellfire Peninsula (Thrallmar)",
                "Mack Diver - Zangarmarsh (Zabra'jin)",
            },
            alliance = {
                "Lebowski - Hellfire Peninsula (Honor Hold)",
                "K. Lee Smallfry - Zangarmarsh (Telredor)",
            },
        },
    },
}

KyroProfGuideData.ProfessionList = KyroProfGuideData.ProfessionList or {}
table.insert(KyroProfGuideData.ProfessionList, "Engineering")
